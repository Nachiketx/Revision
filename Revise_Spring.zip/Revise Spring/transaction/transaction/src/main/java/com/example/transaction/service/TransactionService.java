package com.example.transaction.service;

import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import com.example.transaction.dtos.BalanceDTO;
import com.example.transaction.dtos.InputDto;
import com.example.transaction.dtos.ViewDto;
import com.example.transaction.entities.Transaction;
import com.example.transaction.repo.TransactionRepository;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;

    public TransactionService(TransactionRepository transactionRepository){
        this.transactionRepository = transactionRepository;
    }

    public ViewDto create(InputDto input){
        Transaction transaction = new Transaction();
        transaction.setTitle(input.getTitle());
        transaction.setAmount(input.getAmount());
        transaction.setDate(input.getDate());
        transaction.setDescription(input.getDescription());
        transaction.setType(input.getType());
        Transaction savedTransaction = transactionRepository.save(transaction);
        //TransactionMapper mapper = new TransactionMapper();
        return TransactionMapper.toDto(savedTransaction);    
    }

    public ViewDto getById(Long id) throws Exception {
        Transaction transaction = transactionRepository.findById(id)
                .orElseThrow(() -> new 
                Exception("Transaction not found with id: " + id));
        return TransactionMapper.toDto(transaction);
    }    

    public List<ViewDto> getAll(){
        List<Transaction> transactions = 
                transactionRepository.findAllOrderByDateAscIdAsc();
        List<ViewDto> viewDtos = new ArrayList<>();
        for(Transaction transaction : transactions){
            viewDtos.add(TransactionMapper.toDto(transaction));
        }
        return viewDtos;
    }

    public BalanceDTO getBalance(){
        List<Transaction> transactions = 
                transactionRepository.findAll();

        BigDecimal income = new BigDecimal(0.0);
        BigDecimal expense = new BigDecimal(0.0);
        for(Transaction transaction : transactions){
            if(transaction.getType().equals("INCOME")){
                income = income.add(transaction.getAmount());
            } else if(transaction.getType().equals("EXPENSE")){
                expense = expense.add(transaction.getAmount());
            }
        }
        return new BalanceDTO(income, expense);
    }

    public List<ViewDto> filterTransactions(BigDecimal minAmount, 
        BigDecimal maxAMount){
        List<Transaction> transactions = 
                transactionRepository.findAll();
        List<ViewDto> filteredDtos = new ArrayList<>();
        for(Transaction transaction : transactions){
            if(transaction.getAmount().compareTo(minAmount) >= 0 &&
               transaction.getAmount().compareTo(maxAMount) <= 0){
                filteredDtos.add(TransactionMapper.toDto(transaction));
            }    
        }
        return filteredDtos;
    }
}
