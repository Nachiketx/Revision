package com.example.transaction.service;

import com.example.transaction.dtos.InputDto;
import com.example.transaction.dtos.ViewDto;
import com.example.transaction.entities.Transaction;

public class TransactionMapper {
    //
    public static Transaction toEntity(ViewDto viewDto) {
    //public Transaction toEntity(InputDto inputDto) {
        // Mapping logic from ViewDto to Transaction entity
        if(viewDto == null) {
        //if(inputDto == null) {
            return null;
        }   
        Transaction transaction = new Transaction();
        transaction.setId(viewDto.getId());
        transaction.setTitle(viewDto.getTitle());
        transaction.setAmount(viewDto.getAmount());
        transaction.setDate(viewDto.getDate()); 
        transaction.setDescription(viewDto.getDescription());
        transaction.setType(viewDto.getType());
        return transaction; 
    }
    
    public static ViewDto toDto(Transaction transaction) {
        // Mapping logic from Transaction entity to ViewDto
        if(transaction == null) {
            return null;
        }   
        ViewDto viewDto = new ViewDto();
        viewDto.setId(transaction.getId());
        viewDto.setTitle(transaction.getTitle());
        viewDto.setAmount(transaction.getAmount());
        viewDto.setDate(transaction.getDate()); 
        viewDto.setDescription(transaction.getDescription());
        viewDto.setType(transaction.getType());
        return viewDto; 
    }
}
