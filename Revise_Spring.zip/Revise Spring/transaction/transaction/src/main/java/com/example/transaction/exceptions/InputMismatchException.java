package com.example.transaction.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class InputMismatchException extends Exception{
    public InputMismatchException(String message){
        super(message);
    }

}
