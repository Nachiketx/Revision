package com.example.transaction.dtos;

import java.math.BigDecimal;

public class BalanceDTO {
    private BigDecimal income;
    private BigDecimal expense;

    public BigDecimal getIncome() {
        return this.income;
    }

    public void setIncome(BigDecimal income) {
        this.income = income;
    }

    public BigDecimal getExpense() {
        return this.expense;
    }

    public void setExpense(BigDecimal expense) {
        this.expense = expense;
    }

    public BalanceDTO(BigDecimal income, BigDecimal expense) {
        this.income = income;
        this.expense = expense;
    }
}
