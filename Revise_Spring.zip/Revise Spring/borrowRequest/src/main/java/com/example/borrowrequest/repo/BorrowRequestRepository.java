package com.example.borrowrequest.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.borrowrequest.model.BorrowRequest;

public interface BorrowRequestRepository extends 
    JpaRepository<BorrowRequest, Long>{

}
