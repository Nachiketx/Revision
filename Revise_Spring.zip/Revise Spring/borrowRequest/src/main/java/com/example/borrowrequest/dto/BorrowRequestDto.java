package com.example.borrowrequest.dto;

import java.time.LocalDate;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class BorrowRequestDto {
    //predefined list of alpha numeric constants
    public enum StatusTypes{
         PENDING, APPROVED, REJECTED
    }

    private Long id;

    @NotBlank(message = "borrowerName is required")
    private String borrowerName;
    @NotNull(message = "ItemId is required")
    private String itemId;
    @NotBlank(message = "status is required")
    //private String status; // PENDING, APPROVED, REJECTED
    @Enumerated(EnumType.STRING)
    private StatusTypes status; // PENDING, APPROVED, REJECTED

    private LocalDate startDate;
    private LocalDate endDate;

    public BorrowRequestDto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBorrowerName() {
        return borrowerName;
    }

    public void setBorrowerName(String borrowerName) {
        this.borrowerName = borrowerName;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    // public String getStatus() {
    //     return status;
    // }

    // public void setStatus(String status) {
    //     this.status = status;
    // }

    

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public StatusTypes getStatus() {
        return status;
    }

    public void setStatus(StatusTypes status) {
        this.status = status;
    }

}
