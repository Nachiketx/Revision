package com.example.borrowrequest.service;

import java.util.List;
import com.example.borrowrequest.dto.BorrowRequestDto;
import com.example.borrowrequest.model.BorrowRequest;

public interface BorrowRequestService {

    BorrowRequestDto create(BorrowRequestDto dto);
    BorrowRequestDto get(Long id);
    List<BorrowRequestDto> getList();

    BorrowRequestDto update(Long id, BorrowRequestDto dto);
    Boolean delete(Long id);

    //2 helper methods
    BorrowRequestDto entityToDto(BorrowRequest entity);
    BorrowRequest dtoToEntity(BorrowRequestDto dto);
}
