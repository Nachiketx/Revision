package com.example.borrowrequest.exceptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // @ExceptionHandler({MethodArgumentNotValidException.class})
    // public ResponseEntity<Map<String, String>> 
    //     showValidationErrors(MethodArgumentNotValidException ex){
        
    //     Map<String, String> errorWithFieldName = new HashMap<>();
    //     ex.getBindingResult().getAllErrors().forEach((error) -> {
            
    //         String field = ((FieldError)error).getField();
    //         String message = error.getDefaultMessage();
    //         errorWithFieldName.put(field, message);    
    //     });
    //     return ResponseEntity.status(400).body(errorWithFieldName);
    // }

    @ExceptionHandler({MethodArgumentNotValidException.class,
        DataIntegrityViolationException.class})
    public Object handleValidation(MethodArgumentNotValidException ex) {
        //return ResponseEntity.badRequest()
        //        .body(ex.getBindingResult().getAllErrors().get(0).getDefaultMessage());

        // return ex.getBindingResult().getAllErrors().stream().
        // map(error -> error.getDefaultMessage()).toList();

        //ex.getBindingResult().getAllErrors().forEach(System.out::println);
        List<String> errors = new ArrayList<>();

        ex.getBindingResult().getAllErrors().forEach(
            e -> errors.add(e.getDefaultMessage()));
        
        return errors;
    }
}
