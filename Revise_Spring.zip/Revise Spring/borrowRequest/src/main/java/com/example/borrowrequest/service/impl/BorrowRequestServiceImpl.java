package com.example.borrowrequest.service.impl;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.example.borrowrequest.dto.BorrowRequestDto;
import com.example.borrowrequest.dto.BorrowRequestDto.StatusTypes;
import com.example.borrowrequest.model.BorrowRequest;
import com.example.borrowrequest.service.BorrowRequestService;
import com.example.borrowrequest.repo.*;

@Service
public class BorrowRequestServiceImpl implements BorrowRequestService{

    private final BorrowRequestRepository borrowRequestRepository;

    public BorrowRequestServiceImpl(
            BorrowRequestRepository borrowRequestRepository) {
        this.borrowRequestRepository = borrowRequestRepository;
    }

    @Override
    public BorrowRequestDto create(BorrowRequestDto dto) {
        BorrowRequest bRequest = dtoToEntity(dto);
        bRequest.setId(null);
        BorrowRequest savedBorrowRequest = 
        borrowRequestRepository.save(bRequest);
        return entityToDto(savedBorrowRequest);
    }

    @Override
    @Transactional(readOnly = true)
    public BorrowRequestDto get(Long id) {
        BorrowRequest bRequest = borrowRequestRepository
        .findById(id).orElseThrow(
            () -> new RuntimeException("BorrowRequest not found with id: " + id)
        );
        return entityToDto(bRequest);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BorrowRequestDto> getList() {
        return borrowRequestRepository.findAll()
        .stream().map(b -> entityToDto(b)).toList();
        //.stream().map(this::entityToDto).toList();
    }

    @Override
    public BorrowRequestDto entityToDto(BorrowRequest entity) {
        BorrowRequestDto bRequestDto = new BorrowRequestDto();
        bRequestDto.setId(entity.getId());
        bRequestDto.setBorrowerName(entity.getBorrowerName());
        bRequestDto.setEndDate(entity.getEndDate());
        bRequestDto.setItemId(entity.getItemId());
        bRequestDto.setStartDate(entity.getStartDate());
        //bRequestDto.setStatus(entity.getStatus());
        bRequestDto.setStatus(StatusTypes.valueOf(entity.getStatus()));
        return bRequestDto;
    }

    @Override
    public BorrowRequest dtoToEntity(BorrowRequestDto dto) {
         BorrowRequest bRequest = new BorrowRequest();
        bRequest.setBorrowerName(dto.getBorrowerName());
        bRequest.setEndDate(dto.getEndDate());
        bRequest.setItemId(dto.getItemId());
        bRequest.setStartDate(dto.getStartDate());
        bRequest.setStatus(dto.getStatus().name());
        return bRequest;
    }

    @Override
    public BorrowRequestDto update(Long id, BorrowRequestDto dto) {
        BorrowRequest existingBorrowRequest = borrowRequestRepository.findById(id).
            orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, id+ 
                "Not Found!"));
        if(dto.getBorrowerName() != null){
            existingBorrowRequest.setBorrowerName(dto.getBorrowerName());
        }
        return entityToDto(borrowRequestRepository.save(existingBorrowRequest));
    }

    @Override
    public Boolean delete(Long id) {
       BorrowRequest existingBorrowRequest = borrowRequestRepository.findById(id).
            orElse(null);

        if(null == existingBorrowRequest){
            return false;
        }
        borrowRequestRepository.deleteById(existingBorrowRequest.getId());
        return true;
    }

}
