package com.example.borrowrequest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BorrowRequestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BorrowRequestApplication.class, args);
	}

}
