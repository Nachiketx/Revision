package com.example.borrowrequest.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.borrowrequest.dto.BorrowRequestDto;
import com.example.borrowrequest.service.BorrowRequestService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/borrow")
public class BorrowRequestController {

    private final BorrowRequestService borrowRequestService;

    public BorrowRequestController(BorrowRequestService borrowRequestService) {
        this.borrowRequestService = borrowRequestService;
    }

    @PostMapping
    public ResponseEntity<BorrowRequestDto> postBorrowRequest(@Valid 
        @RequestBody 
            BorrowRequestDto borrowRequestDto) {
        //return borrowRequestService.create(borrowRequestDto);
        return new ResponseEntity<BorrowRequestDto>(
                borrowRequestService.create(borrowRequestDto),
            HttpStatus.CREATED);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> deleteById(@PathVariable Long id){
    //public ResponseEntity<String> deleteById(@PathVariable Long id){
    return new ResponseEntity<Boolean>(borrowRequestService.delete(id), 
        HttpStatus.NO_CONTENT);
        //return ResponseEntity.status(405).body("Delete is not allowed");
    }

    

}
