package com.example.borrowRequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BorrowRequestApplicationTests {

	@Test
	void contextLoads() {
	}

}
