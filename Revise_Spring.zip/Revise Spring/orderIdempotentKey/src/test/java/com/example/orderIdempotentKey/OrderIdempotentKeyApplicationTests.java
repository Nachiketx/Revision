package com.example.orderIdempotentKey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderIdempotentKeyApplicationTests {

	@Test
	void contextLoads() {
	}

}
