package com.example.orderIdempotentKey.service;

import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.orderIdempotentKey.entity.Order;
import com.example.orderIdempotentKey.repo.OrderRepository;
import jakarta.transaction.Transactional;

@Service
// @service
public class OrderService {

    private final OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    // Implement the transaction layer in service
    @Transactional
    public Order create(Order o, String idempotentKey) {
        if (idempotentKey.isBlank()) {
            throw new IllegalArgumentException("Key is required.");
        }
        Order existingOrder = 
            orderRepository.findByIdempotentKey(idempotentKey).orElse(null);
        if (existingOrder != null) {
            throw new 
            IllegalArgumentException("There should NOT be any order " + 
                " with the mentioned idemptotent key");
        }
        Order order = new Order();
        order.setIdempotentKey(idempotentKey);
        order.setProdName(o.getProdName());
        order.setQuantity(o.getQuantity());
        return orderRepository.save(order);
    }

    @Transactional
    public Optional<Order> getOrder(Long id){
        Optional<Order> order = orderRepository.findById(id);
        if(order == null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        }
        return order;
    }

}
