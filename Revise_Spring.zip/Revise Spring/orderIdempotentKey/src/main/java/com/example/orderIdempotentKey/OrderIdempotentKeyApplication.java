package com.example.orderIdempotentKey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderIdempotentKeyApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderIdempotentKeyApplication.class, args);
	}

}
