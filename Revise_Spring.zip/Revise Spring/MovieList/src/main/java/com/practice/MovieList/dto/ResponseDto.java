package com.practice.MovieList.dto;

public class ResponseDto {

    private String movieTitle;
    private double avgRating;
    private int reviewCount;

    public String getMovieTitle() {
        return movieTitle;
    }
    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }
    public double getAvgRating() {
        return avgRating;
    }
    public void setAvgRating(double avgRating) {
        this.avgRating = avgRating;
    }
    public int getReviewCount() {
        return reviewCount;
    }
    public void setReviewCount(int reviewCount) {
        this.reviewCount = reviewCount;
    }
    public ResponseDto() {
    }
    public ResponseDto(String movieTitle, double avgRating, int reviewCount) {
        this.movieTitle = movieTitle;
        this.avgRating = avgRating;
        this.reviewCount = reviewCount;
    }

}
