package com.practice.MovieList.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class RequestDto {

    @NotBlank
    private String movieTitle;

    @Size(max = 2000)
    private String comment;

    @Min(1) @Max(10)
    private int rating;

    public String getMovieTitle() {
        return movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public RequestDto() {
    }

    public RequestDto(@NotBlank String movieTitle, @Size(max = 2000) String comment, @Min(1) @Max(10) int rating) {
        this.movieTitle = movieTitle;
        this.comment = comment;
        this.rating = rating;
    }

    


}
