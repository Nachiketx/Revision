package com.practice.MovieList.contoller;

import java.util.List;
import java.util.ArrayList;

import org.springframework.web.bind.annotation.RestController;

import com.practice.MovieList.dto.RequestDto;
import com.practice.MovieList.dto.ResponseDto;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;



@RestController
public class MovieController {

    private List<RequestDto> list = new ArrayList<>();

    // @PostMapping
    // public ResponseEntity<RequestDto> create(@RequestBody RequestDto request) {
    //     list.add(request);
    //     return new ResponseEntity<>(request, HttpStatus.CREATED);
    // }

    @PostMapping
    public ResponseEntity<List<RequestDto>> create(@Valid @RequestBody RequestDto request) {
        list.add(request);
        return new ResponseEntity<>(list, HttpStatus.CREATED);
    }
    
    @GetMapping
    public ResponseEntity<ResponseDto> getMethodName(@Valid @RequestParam String movieTitle) {
        if(list.isEmpty()){
            return ResponseEntity.notFound().build();
        }
        double totalRating = 0.0; 
        int reviewCount = 0;
        for(RequestDto dto: list) {
            if(dto.getMovieTitle().equals(movieTitle)) {
                totalRating += dto.getRating();
                reviewCount++;
            }
        }
        if(reviewCount == 0) {
            return ResponseEntity.notFound().build();
        }
        double avgRating = totalRating / reviewCount;
        return new ResponseEntity<>(new ResponseDto(movieTitle, avgRating, reviewCount), HttpStatus.OK);
    }
}
