package com.practice.MovieList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieListApplicationTests {

	@Test
	void contextLoads() {
	}

}
