package com.practice.MovieList;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.practice.MovieList.dto.RequestDto;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class MovieControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private RequestDto validDto;

    @BeforeEach
    void setup() {
        validDto = new RequestDto();
        validDto.setMovieTitle("Inception");
        validDto.setComment("Great movie");
        validDto.setRating(8);
    }

    /* =======================
       RequestDto Validation
       ======================= */

    @Test void movieTitle_null_shouldFail() throws Exception {
        validDto.setMovieTitle(null);
        postExpectBadRequest(validDto);
    }

    @Test void movieTitle_blank_shouldFail() throws Exception {
        validDto.setMovieTitle(" ");
        postExpectBadRequest(validDto);
    }

    @Test void movieTitle_empty_shouldFail() throws Exception {
        validDto.setMovieTitle("");
        postExpectBadRequest(validDto);
    }

    @Test void comment_null_allowed() throws Exception {
        validDto.setComment(null);
        postExpectCreated(validDto);
    }

    @Test void comment_exact2000_allowed() throws Exception {
        validDto.setComment("a".repeat(2000));
        postExpectCreated(validDto);
    }

    @Test void comment_above2000_shouldFail() throws Exception {
        validDto.setComment("a".repeat(2001));
        postExpectBadRequest(validDto);
    }

    @Test void rating_zero_shouldFail() throws Exception {
        validDto.setRating(0);
        postExpectBadRequest(validDto);
    }

    @Test void rating_one_allowed() throws Exception {
        validDto.setRating(1);
        postExpectCreated(validDto);
    }

    @Test void rating_ten_allowed() throws Exception {
        validDto.setRating(10);
        postExpectCreated(validDto);
    }

    @Test void rating_aboveTen_shouldFail() throws Exception {
        validDto.setRating(11);
        postExpectBadRequest(validDto);
    }

    /* =======================
       POST API Tests
       ======================= */

    @Test void post_valid_shouldReturn201() throws Exception {
        postExpectCreated(validDto);
    }

    @Test void post_multiple_reviews_allowed() throws Exception {
        postExpectCreated(validDto);
        validDto.setRating(9);
        postExpectCreated(validDto);
    }

    @Test void post_invalid_rating_should400() throws Exception {
        validDto.setRating(-1);
        postExpectBadRequest(validDto);
    }

    @Test void post_blank_title_should400() throws Exception {
        validDto.setMovieTitle("");
        postExpectBadRequest(validDto);
    }

    @Test void post_large_comment_should400() throws Exception {
        validDto.setComment("x".repeat(3000));
        postExpectBadRequest(validDto);
    }

    /* =======================
       GET API Tests
       ======================= */

    @Test void get_existing_movie_should200() throws Exception {
        postExpectCreated(validDto);

        mockMvc.perform(get("/")
                .param("movieTitle", "Inception"))
                .andExpect(status().isOk());
    }

    @Test void get_non_existing_movie_should404() throws Exception {
        mockMvc.perform(get("/")
                .param("movieTitle", "Unknown"))
                .andExpect(status().isNotFound());
    }

    @Test void get_single_review_avg() throws Exception {
        postExpectCreated(validDto);

        mockMvc.perform(get("/")
                .param("movieTitle", "Inception"))
                .andExpect(jsonPath("$.avgRating").value(8.0))
                .andExpect(jsonPath("$.reviewCount").value(1));
    }

    @Test void get_multiple_reviews_avg() throws Exception {
        postExpectCreated(validDto);
        validDto.setRating(10);
        postExpectCreated(validDto);

        mockMvc.perform(get("/")
                .param("movieTitle", "Inception"))
                .andExpect(jsonPath("$.avgRating").value(9.0))
                .andExpect(jsonPath("$.reviewCount").value(2));
    }

    @Test void get_case_sensitive_mismatch() throws Exception {
        postExpectCreated(validDto);

        mockMvc.perform(get("/")
                .param("movieTitle", "inception"))
                .andExpect(status().isNotFound());
    }

    @Test void get_without_param_should400() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isBadRequest());
    }

    @Test void get_multiple_movies_only_counts_matching() throws Exception {
        postExpectCreated(validDto);

        RequestDto other = new RequestDto();
        other.setMovieTitle("Avatar");
        other.setRating(10);
        postExpectCreated(other);

        mockMvc.perform(get("/")
                .param("movieTitle", "Inception"))
                .andExpect(jsonPath("$.reviewCount").value(1));
    }

    @Test void get_avgRating_decimal() throws Exception {
        validDto.setRating(7);
        postExpectCreated(validDto);
        validDto.setRating(8);
        postExpectCreated(validDto);

        mockMvc.perform(get("/")
                .param("movieTitle", "Inception"))
                .andExpect(jsonPath("$.avgRating").value(7.5));
    }

    @Test void get_after_single_post() throws Exception {
        postExpectCreated(validDto);

        mockMvc.perform(get("/")
                .param("movieTitle", "Inception"))
                .andExpect(status().isOk());
    }

    @Test void get_when_list_empty_should404() throws Exception {
        mockMvc.perform(get("/")
                .param("movieTitle", "Inception"))
                .andExpect(status().isNotFound());
    }

    /* =======================
       Helper Methods
       ======================= */

    private void postExpectCreated(RequestDto dto) throws Exception {
        mockMvc.perform(post("/")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isCreated());
    }

    private void postExpectBadRequest(RequestDto dto) throws Exception {
        mockMvc.perform(post("/")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isBadRequest());
    }
}


