package com.example.hibernate2.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.hibernate2.entities.Store;
import com.example.hibernate2.repositories.StoreRepository;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping ("/stores")  
public class StoreController {

    private final StoreRepository storeRepository;

    public StoreController(StoreRepository storeRepository) {
        this.storeRepository = storeRepository;
    }

    @PostMapping("/createStore")
    public ResponseEntity<Store> 
        postMethodName(@RequestBody Store store) {
        //assuming that store will have a list of products
        if(store.getProducts() != null) {
            store.getProducts().forEach(product -> product.setStore(store));
        } 

        return new ResponseEntity<>(storeRepository.save(store), 
                HttpStatus.CREATED );
    }
    
}
