package com.example.hibernate2.entities;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false, unique = true)
    private String orderNumber;

    @NotNull
    @Column(nullable = false)
    private String status; // CREATED, PAID, SHIPPED, CANCELLED

    @CreationTimestamp
    private LocalDate createdAt;

    /*
     * OneToOne with Cart
     * - Order is the parent
     * - Cart lifecycle depends on Order
     * - FK is stored in Cart table
     */
    @OneToOne
    private Cart cart;

    /*
     * ManyToMany with Product
     * - One Order can contain many Products
     * - One Product can appear in many Orders
     * - Join table is REQUIRED
     */
    @ManyToMany
    private List<Product> products = new ArrayList<>();

    // ================= Helper Methods =================
    public void setCart(Cart cart) {
        this.cart = cart;
        if (cart != null) {
            cart.setOrder(this);
        }
    }

    public void addProduct(Product product) {
        this.products.add(product);
    }

    public void removeProduct(Product product) {
        this.products.remove(product);
    }

    // ================= Getters & Setters =================
    public Long getId() {
        return id;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public String getStatus() {
        return status;
    }

    public LocalDate getCreatedAt() {
        return createdAt;
    }

    public Cart getCart() {
        return cart;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public Order() {
    }
}
