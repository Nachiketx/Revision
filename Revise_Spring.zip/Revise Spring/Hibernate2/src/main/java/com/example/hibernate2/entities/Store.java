package com.example.hibernate2.entities;
import java.time.LocalDate;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.util.*;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "store")
public class Store {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(min = 1, max = 200) //And this is for String
    //@Min(1) @Max(200) - This is only for Integer or Long
    private String name;

    @NotBlank
    @Size(min = 1)
    private String address;

    @UpdateTimestamp
    private LocalDate updatedAt;

    @CreationTimestamp
    private LocalDate createdAt;

    public LocalDate getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }

    @OneToMany(mappedBy = "store", cascade = CascadeType.PERSIST) //This will always be a inverse side( this table does not contain
    //any foreign key) - We will use only and only mappedBy 
    @JsonManagedReference

    private List<Product> products = new ArrayList<>(); 

    //create helper methods for storing products as part of store
    public void addProduct(Product product){
        products.add(product);
        product.setStore(this);
    }

    public void removeProduct(Product product){
        products.remove(product);
        product.setStore(null);
    }


    
    //Write your validation logic here
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    //@NotNull
    //@Size(min = 1, max = 200)
    public void setName(String name) {
        //Write your name fields data here
        if(name == null || name.trim().isEmpty()){
            throw new IllegalArgumentException("Name can not be blank.");
        }
        if(name.length() > 200){
            throw new 
            IllegalArgumentException("Name Length can not be more than 200");
        }
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Store(Long id, String name, String address, LocalDate updatedAt, LocalDate createdAt,
            List<Product> products) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.updatedAt = updatedAt;
        this.createdAt = createdAt;
        this.products = products;
    }

    public Store() {
    }

    public LocalDate getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDate updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

}
