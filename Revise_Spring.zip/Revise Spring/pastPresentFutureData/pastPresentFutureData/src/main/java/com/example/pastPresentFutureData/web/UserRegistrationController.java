package com.example.pastPresentFutureData.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pastPresentFutureData.model.UserRegistrationRequest;
import com.example.pastPresentFutureData.service.UserRegistrationService;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/users")
public class UserRegistrationController {

    private UserRegistrationService userRegistrationService;

    public UserRegistrationController(UserRegistrationService userRegistrationService) {
        this.userRegistrationService = userRegistrationService;
    }

    @PostMapping
    public ResponseEntity<String> postMethodName(@Valid @RequestBody 
            UserRegistrationRequest entity) {
        String response = userRegistrationService.create(entity);
        return ResponseEntity.status(201).body(response);
    }
    
}
