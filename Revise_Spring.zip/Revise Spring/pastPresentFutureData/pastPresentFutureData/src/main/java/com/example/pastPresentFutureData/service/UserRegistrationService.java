package com.example.pastPresentFutureData.service;

import org.springframework.stereotype.Service;

import com.example.pastPresentFutureData.model.UserRegistrationRequest;
import com.example.pastPresentFutureData.repo.UserRegistrationRepository;

@Service
public class UserRegistrationService {

    private UserRegistrationRepository userRegistrationRepository;

    public UserRegistrationService(UserRegistrationRepository 
            userRegistrationRepository){
                this.userRegistrationRepository = userRegistrationRepository;
    }

    public String create(UserRegistrationRequest 
        userRegistrationRequest){
            userRegistrationRepository.save(userRegistrationRequest);
            return "User Registered Successfully";
        }
}
