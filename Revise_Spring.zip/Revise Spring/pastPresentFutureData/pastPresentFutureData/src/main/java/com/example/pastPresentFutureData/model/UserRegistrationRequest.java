package com.example.pastPresentFutureData.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.hibernate.validator.constraints.CreditCardNumber;
import org.hibernate.validator.constraints.URL;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

@Entity
@Table
public class UserRegistrationRequest {

    //user name can not be blank
    //user name has to be between 3 and 20 characters long
    @Id
    @NotBlank(message = "Username cannot be blank")
    @Size(min = 3, max = 20, message = "Username must be between 3 and 20 characters")
    private String username;
    
    
    public void setUsername(String username) {
        this.username = username;
    }

    //password can not be blank
    //password has to be between 8 and 64 characters long
    @NotBlank(message = "Password cannot be blank")
    @Size(min = 8, max = 64, message = "Password must be between 8 and 64 characters")
    private String password;

    //email can not be blank
    //email should be in a correct format
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Invalid email format")
    private String email;

    //Age can not be null
    //Age, minimum us 18 and maximum is 120
    @NotNull(message = "Age is required")
    @Min(value = 18, message = "Age must be at least 18")
    @Max(value = 120, message = "Age must be at most 120")
    private Integer age;

    //salary must be a positive number
    //salary must have 10 digits and 2 decimals max
    @NotNull(message = "Salary is required")
    @Positive(message = "Salary must be positive")
    // @Digits(integer = 10, fraction = 2, 
    //     message = "Salary can have 10 digits and 2 decimals")
    //write annotation to validate salary using precision and scale
    @DecimalMin(value = "0.01", message = "Salary must be greater than 0")
    @DecimalMax(value = "99999999.99", message = "Salary can not exceed 99,999,999.99")
    private BigDecimal salary;

    //Discount must be greater than 0
    //DIscount be less than 50%
    @NotNull(message = "Discount is required")
    @DecimalMin(value = "0.01", message = "Discount must be greater than 0")
    @DecimalMax(value = "0.50", message = "Discount  can not exceed 0.50")    
    private BigDecimal discount;

    //date of birth must be of a past date
    @NotNull(message = "Date of birth is required")
    @Past(message = "Date of birth must be in a past")
    //past or present can also be used
    private LocalDate dateOfBirth;

    //membership must be either present day or could be future date also
    @NotNull(message = "Membership start date is required")
    @FutureOrPresent(message = "Membership start must be today or future date")
    private LocalDate membershipStartDate;

    //URL through which membership was taken, it has to be valid
    @URL(message = "invalid profile URL") 
    @NotBlank(message = "url can not be blank")
    private String profileUrl;

    //Ignore non digit and must be a correct credit number
    @CreditCardNumber(ignoreNonDigitCharacters = true,
        message = "Invalid credit card number"
    )
    private String creditCard;

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public Integer getAge() {
        return age;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public LocalDate getMembershipStartDate() {
        return membershipStartDate;
    }

    public String getProfileUrl() {
        return profileUrl;
    }

    public String getCreditCard() {
        return creditCard;
    }


    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void setMembershipStartDate(LocalDate membershipStartDate) {
        this.membershipStartDate = membershipStartDate;
    }

    public void setProfileUrl(String profileUrl) {
        this.profileUrl = profileUrl;
    }

    public void setCreditCard(String creditCard) {
        this.creditCard = creditCard;
    }

    
}
