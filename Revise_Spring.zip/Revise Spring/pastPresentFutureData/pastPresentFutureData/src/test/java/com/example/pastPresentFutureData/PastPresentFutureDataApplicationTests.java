package com.example.pastPresentFutureData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PastPresentFutureDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
