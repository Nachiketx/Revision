package com.hackerrank.configstyles.service;

public interface NotificationService {
    public ServiceResponse sendNotification(String notification);
}
