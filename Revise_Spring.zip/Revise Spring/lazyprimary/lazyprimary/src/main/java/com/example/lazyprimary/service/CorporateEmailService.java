package com.example.lazyprimary.service;

import com.example.lazyprimary.service.EmailService;

//This is a first implementation class of Email Service
public class CorporateEmailService implements EmailService{

    public CorporateEmailService(){
        System.out.println("CorporateEmailService created");
    }

    @Override
    public String sendEmail(String message){
        return "CORPORATE EMAIL: " + message;
    }
}
