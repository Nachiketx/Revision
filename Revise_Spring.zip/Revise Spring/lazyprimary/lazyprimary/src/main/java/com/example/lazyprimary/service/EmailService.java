package com.example.lazyprimary.service;

public interface EmailService {
    String sendEmail(String message);
}
