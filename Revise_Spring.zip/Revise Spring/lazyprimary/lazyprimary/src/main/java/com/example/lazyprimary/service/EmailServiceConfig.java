package com.example.lazyprimary.service;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;

import com.example.lazyprimary.service.CorporateEmailService;
import com.example.lazyprimary.service.EmailService;
import com.example.lazyprimary.service.MarketingEmailService;

@Configuration
public class EmailServiceConfig {

    @Bean("pranay")
    //@Primary
    public EmailService corporateEmailService(){
        return new CorporateEmailService();
    }

    @Bean
    //@Lazy
    public EmailService marketingEmailService(){
        return new MarketingEmailService();
    }
}
