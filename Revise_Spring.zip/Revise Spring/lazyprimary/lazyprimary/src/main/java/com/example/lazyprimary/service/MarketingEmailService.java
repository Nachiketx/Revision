package com.example.lazyprimary.service;

import com.example.lazyprimary.service.EmailService;

public class MarketingEmailService implements EmailService{

    public MarketingEmailService(){
        System.out.println("MarketingEmailService created");
    }

    @Override
    public String sendEmail(String message){
        return "MARKETING EMAIL: " + message;
    }

}
