package com.example.lazyprimary.controller;
//import here by yourself

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.lazyprimary.service.EmailService;

@RestController
@RequestMapping("/notify")
public class NotificationController {

    private final EmailService corporateEmailService;
    private final EmailService marketingEmailService;

    public NotificationController(
        @Qualifier("pranay")
        EmailService corporateEmailService,
        @Qualifier("marketingEmailService") EmailService 
        marketingEmailService){
        this.corporateEmailService = corporateEmailService;
        this.marketingEmailService = marketingEmailService;
    }

    @GetMapping("/corporate")
    public String sendCorporate(){
        return corporateEmailService.sendEmail("Hello Corporate");
    }

    @GetMapping("/marketing")
    public String sendMarketing(){
        return marketingEmailService.sendEmail("Hello Marketing");
    }

}