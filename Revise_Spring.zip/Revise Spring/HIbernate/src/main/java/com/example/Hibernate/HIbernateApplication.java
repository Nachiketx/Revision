package com.example.HIbernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HIbernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(HIbernateApplication.class, args);
	}

}
