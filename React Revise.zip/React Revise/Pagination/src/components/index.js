import Pagination from "./Pagination";
import Table from "./Table";

export { Pagination, Table };
