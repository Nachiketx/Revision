import React from "react";
import MovieCard from "./MovieCard";

const Watchlist = () => {
  return (
    <div data-testid="watchlist-container">
      {/* Provide the total count of movies watchlisted */}
      <h2>Watchlist {<span>(1)</span>}</h2>
      {/* <p data-testid="watchlist-empty">Your watchlist is empty.</p> */}
      <div>
        <div data-testid="movie-container" className="movies-container">
          <MovieCard />
        </div>
        <button data-testid="clear-watchlist-btn">Clear Watchlist</button>
      </div>
    </div>
  );
};

export default Watchlist;
