#ifndef PAYMENT_H
#define PAYMENT_H

#include <string>
#include <iostream>
#include "Order.h"

class Order;

class Payment {
private:
    int paymentId;
    Order* order;
    double amount;
    std::string paymentMethod;
    std::string paymentDate;
    std::string status;  // e.g., "completed", "pending"

public:
    Payment(int id, Order* ord, double amt, const std::string & method);
    ~Payment();

    int getPaymentId() const;
    Order* getOrder() const;
    double getAmount() const;
    std::string getPaymentMethod() const;
    std::string getPaymentDate() const;
    std::string getStatus() const;

    void processPayment();
    void refundPayment();

    void setStatus(const std::string & newStatus);
    void display() const;
};

#endif
