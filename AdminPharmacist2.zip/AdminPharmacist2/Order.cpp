#include "Order.h"
#include <iostream>

Order::Order(int id, Customer* cust, double batch) : orderId(id), customer(cust), totalAmount(0.0), batchNo(batch), payment(nullptr), orderDate("2024-01-01") {}

Order::~Order() {}

int Order::getOrderId() const { return orderId; }
Customer* Order::getCustomer() const { return customer; }
const std::vector<Medicine*>& Order::getMedicines() const { return medicines; }
double Order::getTotalAmount() const { return totalAmount; }
std::string Order::getOrderDate() const { return orderDate; }
double Order::getBatchNo() const { return batchNo; }

void Order::placeOrder() {
    std::cout << "Order " << orderId << " placed by " << customer->getName() << std::endl;
    calculateTotal();
}

void Order::cancelOrder() {
    std::cout << "Order " << orderId << " cancelled." << std::endl;
    // In real impl, refund etc.
}

void Order::viewOrderDetails() const {
    std::cout << "Order ID: " << orderId << ", Customer: " << customer->getName()
              << ", Total: $" << totalAmount << ", Medicines: " << medicines.size() << std::endl;
    for (const auto* med : medicines) {
        med->display();
    }
}

void Order::addMedicine(Medicine* med) {
    medicines.push_back(med);
}

void Order::calculateTotal() {
    totalAmount = 0.0;
    for (const auto* med : medicines) {
        totalAmount += med->getPrice();
    }
}

void Order::setPayment(Payment* p) {
    payment = p;
}

void Order::setOrderDate(const std::string& date) {
    orderDate = date;
}

void Order::setTotalAmount(double amount) {
    totalAmount = amount;
}
