#include <iostream>
#include <vector>
#include <string>
#include <limits>
#include "AdminPharmacist.h"
#include "Customer.h"
#include "Order.h"
#include "Medicine.h"
#include "Payment.h"
#include "Database.h"

int main() {
    std::cout << "=== Interactive Pharmacy Management System ===" << std::endl;
    
    Database db("pharmacy.db");
    if (!db.open() || !db.initSchema()) {
        std::cerr << "Failed to initialize database." << std::endl;
        return 1;
    }

    std::vector<Medicine*> inventory = db.loadMedicines();
    std::vector<Customer*> customers = db.loadCustomers();
    for (auto* cust : customers) {
        db.loadOrdersForCustomer(cust, inventory);
    }

    AdminPharmacist admin("admin", "admin@pharma.com", "Admin User", "1234567890");
    
    int mainChoice;
    do {
        std::cout << "\n--- Main Menu ---"
                      << "\n1. Admin Panel"
                      << "\n2. Customer Panel" 
                      << "\n0. Exit"
                      << "\nEnter choice: ";
        std::cin >> mainChoice;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        
        if (mainChoice == 1) {
            // Admin Panel
            std::cout << "\nAdmin logged in: " << admin.getName() << std::endl;
            int adminChoice;
            do {
                std::cout << "\nAdmin Menu:"
                          << "\n1. Add Medicine"
                          << "\n2. View Inventory"
                          << "\n3. Add Customer"
                          << "\n4. View Reports"
                          << "\n0. Logout"
                          << "\nChoice: ";
                std::cin >> adminChoice;
                std::cin.ignore();
                
                switch (adminChoice) {
                    case 1: {
                        // Add Medicine
                        int id, stock;
                        std::string name, brand, expiry;
                        double price;
                        std::cout << "Medicine ID: "; std::cin >> id;
                        std::cin.ignore();
                        std::cout << "Name: "; std::getline(std::cin, name);
                        std::cout << "Brand: "; std::getline(std::cin, brand);
                        std::cout << "Price: "; std::cin >> price;
                        std::cout << "Stock: "; std::cin >> stock;
                        std::cin.ignore();
                        std::cout << "Expiry (YYYY-MM-DD): "; std::getline(std::cin, expiry);
                        
                        Medicine* newMed = new Medicine(id, name, brand, price, stock, expiry);
                        inventory.push_back(newMed);
                        db.addMedicine(*newMed);
                        newMed->addMedicine();
                        break;
                    }
                    case 2: {
                        // View Inventory
                        std::cout << "--- Inventory ---" << std::endl;
                        for (const auto* med : inventory) {
                            med->display();
                        }
                        break;  
                    }
                    case 3: {
                        // Add Customer
                        int custId;
                        std::string custName, phone, email;
                        std::cout << "Customer ID: "; std::cin >> custId;
                        std::cin.ignore();
                        std::cout << "Name: "; std::getline(std::cin, custName);
                        std::cout << "Phone: "; std::getline(std::cin, phone);
                        std::cout << "Email: "; std::getline(std::cin, email);
                        
                        Customer* newCust = new Customer(custId, custName, phone, email);
                        customers.push_back(newCust);
                        db.addCustomer(*newCust);
                        newCust->registerCustomer();
                        break;
                    }
                    case 4: {
                        admin.viewReports(customers, inventory);
                        break;
                    }
                }
            } while (adminChoice != 0);
            
        } else if (mainChoice == 2) {
            // Customer Panel
            std::cout << "Enter Customer ID: ";
            int custId; std::cin >> custId;
            Customer* cust = nullptr;
            for (auto* c : customers) {
                if (c->getCustomerId() == custId) {
                    cust = c;
                    break;
                }
            }
            
            if (cust) {
                std::cout << "Welcome " << cust->getName() << "!" << std::endl;
                int custChoice;
                int nextOrderId = db.getNextOrderId();
                int nextPaymentId = db.getNextPaymentId();
                do {
                    std::cout << "\nCustomer Menu:"
                          << "\n1. Browse Medicines"
                          << "\n2. Place Order"
                          << "\n3. View My Orders"
                          << "\n0. Logout"
                          << "\nChoice: "; 
                    std::cin >> custChoice;
                    std::cin.ignore();
                    
                    if (custChoice == 1) {
                        std::cout << "Available Medicines:" << std::endl;
                        for (const auto* med : inventory) {
                            med->display();
                        }
                    } else if (custChoice == 2) {
                        // Place Order
                        Order* order = new Order(nextOrderId++, cust, 0.0);
                        std::cout << "Enter Medicine ID to add (0 to finish order): ";
                        int medId;
                        while (std::cin >> medId && medId != 0) {
                            for (auto* med : inventory) {
                                if (med->getMedicineId() == medId && med->getStock() > 0) {
                                    order->addMedicine(med);
                                    med->updateStock(med->getStock() - 1);
                                    db.updateMedicineStock(med->getMedicineId(), med->getStock());
                                    std::cout << "Added " << med->getName() << std::endl;
                                    break;
                                }
                            }
                            std::cout << "Next Medicine ID (0 to finish): ";
                        }
                        order->placeOrder();
                        order->viewOrderDetails();
                        db.addOrder(*order);
                        for (const auto* med : order->getMedicines()) {
                            db.addOrderMedicine(order->getOrderId(), med->getMedicineId());
                        }
                        
                        // Process Payment
                        Payment* payment = new Payment(nextPaymentId++, order, order->getTotalAmount(), "Cash");
                        payment->processPayment();
                        db.addPayment(*payment);
                        order->setPayment(payment);
                        cust->addPurchase(order);
                        std::cout << "Order completed successfully!" << std::endl;
                    } else if (custChoice == 3) {
                        cust->display();
                    }
                } while (custChoice != 0);
            } else {
                std::cout << "Customer not found. Register first via Admin panel." << std::endl;
            }
        }
    } while (mainChoice != 0);
    
    // Cleanup
    for (auto* med : inventory) delete med;
    for (auto* cust : customers) {
        // Cleanup orders would be recursive, simplified
        delete cust;
    }

    db.close();
    
    std::cout << "Thank you for using Pharmacy Management System!" << std::endl;
    return 0;
}


