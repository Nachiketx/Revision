#include "Customer.h"
#include <iostream>

Customer::Customer(int id, const std::string & n, const std::string & ph, const std::string & e)
    : customerId(id), name(n), phone(ph), email(e) {}

Customer::~Customer() {}

int Customer::getCustomerId() const { return customerId; }
std::string Customer::getName() const { return name; }
std::string Customer::getPhone() const { return phone; }
std::string Customer::getEmail() const { return email; }
std::vector<Order*>& Customer::getPurchaseHistory() { return purchaseHistory; }

void Customer::registerCustomer() {
    std::cout << "Customer registered: " << name << " (ID: " << customerId << ")" << std::endl;
}

void Customer::updateProfile(const std::string & newName, const std::string & newPhone, const std::string & newEmail) {
    name = newName;
    phone = newPhone;
    email = newEmail;
    std::cout << "Profile updated for " << name << std::endl;
}

void Customer::addPurchase(Order* order) {
    purchaseHistory.push_back(order);
    std::cout << "Purchase added to " << name << "'s history." << std::endl;
}

void Customer::display() const {
    std::cout << "Customer ID: " << customerId << ", Name: " << name
              << ", Phone: " << phone << ", Email: " << email
              << ", Purchases: " << purchaseHistory.size() << std::endl;
}
