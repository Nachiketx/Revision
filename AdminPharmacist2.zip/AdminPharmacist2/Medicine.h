#ifndef MEDICINE_H
#define MEDICINE_H

#include <string>
#include <iostream>

class Medicine {
private:
    int medicineId;
    std::string name;
    std::string brand;
    double price;
    int stock;
    std::string expiryDate;  // Simplified as string YYYY-MM-DD

public:
    Medicine(int id, const std::string & n, const std::string & b, double p, int s, const std::string & exp);
    ~Medicine();

    int getMedicineId() const;
    std::string getName() const;
    std::string getBrand() const;
    double getPrice() const;
    int getStock() const;
    std::string getExpiryDate() const;

    void addMedicine();
    void updateStock(int newStock);
    bool checkExpiry(const std::string & currentDate) const;  // Simple comparison

    void display() const;
};

#endif
