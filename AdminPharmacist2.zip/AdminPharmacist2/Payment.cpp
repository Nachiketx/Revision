#include "Payment.h"

Payment::Payment(int id, Order* ord, double amt, const std::string & method)
    : paymentId(id), order(ord), amount(amt), paymentMethod(method), paymentDate("2024-01-01"), status("pending") {}

Payment::~Payment() {}

int Payment::getPaymentId() const { return paymentId; }
Order* Payment::getOrder() const { return order; }
double Payment::getAmount() const { return amount; }
std::string Payment::getPaymentMethod() const { return paymentMethod; }
std::string Payment::getPaymentDate() const { return paymentDate; }
std::string Payment::getStatus() const { return status; }

void Payment::processPayment() {
    status = "completed";
    std::cout << "Payment " << paymentId << " processed for Order " << order->getOrderId() << std::endl;
}

void Payment::refundPayment() {
    status = "refunded";
    std::cout << "Payment " << paymentId << " refunded." << std::endl;
}

void Payment::setStatus(const std::string & newStatus) {
    status = newStatus;
}

void Payment::display() const {
    std::cout << "Payment ID: " << paymentId << ", Amount: $" << amount
              << ", Method: " << paymentMethod << ", Status: " << status << std::endl;
}
