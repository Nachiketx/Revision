#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>
#include <vector>
#include "Order.h"

class Order;

class Customer {
private:
    int customerId;
    std::string name;
    std::string phone;
    std::string email;
    std::vector<Order*> purchaseHistory;

public:
    Customer(int id, const std::string & n, const std::string & ph, const std::string & e);
    ~Customer();

    int getCustomerId() const;
    std::string getName() const;
    std::string getPhone() const;
    std::string getEmail() const;
    std::vector<Order*>& getPurchaseHistory();

    void registerCustomer();
    void updateProfile(const std::string & newName, const std::string & newPhone, const std::string & newEmail);
    void addPurchase(Order* order);

    void display() const;
};

#endif
