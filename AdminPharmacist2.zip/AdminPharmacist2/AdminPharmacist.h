#ifndef ADMINPHARMACIST_H
#define ADMINPHARMACIST_H

#include <string>
#include <iostream>
#include <vector>
#include "Customer.h"
#include "Medicine.h"

class Customer;
class Medicine;

class AdminPharmacist {
private:
    std::string username;
    std::string email;  // Note: diagram has duplicate 'email', using once
    std::string name;
    std::string phone;

public:
    AdminPharmacist(const std::string & user, const std::string & e, const std::string & n, const std::string & ph);
    ~AdminPharmacist();

    std::string getUsername() const;
    std::string getEmail() const;
    std::string getName() const;
    std::string getPhone() const;

    void manageUsers(std::vector<Customer*>& users);  // e.g., add/remove customer
    void manageInventory(std::vector<Medicine*>& inventory);  // add/update medicine
    void viewReports(const std::vector<Customer*>& users, const std::vector<Medicine*>& inventory);

    void display() const;
};

#endif
