#include "AdminPharmacist.h"

AdminPharmacist::AdminPharmacist(const std::string & user, const std::string & e, const std::string & n, const std::string & ph)
    : username(user), email(e), name(n), phone(ph) {}

AdminPharmacist::~AdminPharmacist() {}

std::string AdminPharmacist::getUsername() const { return username; }
std::string AdminPharmacist::getEmail() const { return email; }
std::string AdminPharmacist::getName() const { return name; }
std::string AdminPharmacist::getPhone() const { return phone; }

void AdminPharmacist::manageUsers(std::vector<Customer*>& users) {
    std::cout << "Managing users... Total customers: " << users.size() << std::endl;
    // Demo: add a dummy customer
    // In full impl, interactive add/remove
}

void AdminPharmacist::manageInventory(std::vector<Medicine*>& inventory) {
    std::cout << "Managing inventory... Total medicines: " << inventory.size() << std::endl;
    // Demo: add/update
}

void AdminPharmacist::viewReports(const std::vector<Customer*>& users, const std::vector<Medicine*>& inventory) {
    std::cout << "Reports - Customers: " << users.size() << ", Medicines: " << inventory.size() << std::endl;
}

void AdminPharmacist::display() const {
    std::cout << "Admin: " << name << " (" << username << "), Email: " << email << std::endl;
}
