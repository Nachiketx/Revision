#ifndef DATABASE_H
#define DATABASE_H

#include <string>
#include <vector>
#include "sqlite3.h"
#include "Customer.h"
#include "Medicine.h"
#include "Order.h"
#include "Payment.h"

class Database {
private:
    sqlite3* db;
    std::string dbPath;

    bool execute(const std::string& sql);
    int getNextId(const std::string& table, const std::string& column);
    Medicine* findMedicineById(int medicineId, const std::vector<Medicine*>& inventory);

public:
    Database(const std::string& path);
    ~Database();

    bool open();
    void close();
    bool initSchema();

    bool addMedicine(const Medicine& med);
    bool updateMedicineStock(int medicineId, int newStock);
    bool addCustomer(const Customer& cust);
    bool addOrder(const Order& order);
    bool addOrderMedicine(int orderId, int medicineId);
    bool addPayment(const Payment& payment);

    int getNextOrderId();
    int getNextPaymentId();

    std::vector<Medicine*> loadMedicines();
    std::vector<Customer*> loadCustomers();
    void loadOrdersForCustomer(Customer* cust, const std::vector<Medicine*>& inventory);
};

#endif