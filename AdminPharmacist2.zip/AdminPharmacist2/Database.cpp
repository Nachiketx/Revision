#include "Database.h"
#include <iostream>
#include <sstream>

Database::Database(const std::string& path) : db(nullptr), dbPath(path) {}

Database::~Database() {
    close();
}

bool Database::open() {
    if (sqlite3_open(dbPath.c_str(), &db) != SQLITE_OK) {
        std::cerr << "Failed to open database: " << sqlite3_errmsg(db) << std::endl;
        return false;
    }
    return true;
}

void Database::close() {
    if (db) {
        sqlite3_close(db);
        db = nullptr;
    }
}

bool Database::execute(const std::string& sql) {
    char* errMsg = nullptr;
    if (sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg) != SQLITE_OK) {
        std::cerr << "SQLite error: " << (errMsg ? errMsg : "Unknown error") << std::endl;
        sqlite3_free(errMsg);
        return false;
    }
    return true;
}

bool Database::initSchema() {
    const std::string schema =
        "CREATE TABLE IF NOT EXISTS medicines ("
        "medicine_id INTEGER PRIMARY KEY,"
        "name TEXT NOT NULL,"
        "brand TEXT NOT NULL,"
        "price REAL NOT NULL,"
        "stock INTEGER NOT NULL,"
        "expiry_date TEXT NOT NULL"
        ");"
        "CREATE TABLE IF NOT EXISTS customers ("
        "customer_id INTEGER PRIMARY KEY,"
        "name TEXT NOT NULL,"
        "phone TEXT NOT NULL,"
        "email TEXT NOT NULL"
        ");"
        "CREATE TABLE IF NOT EXISTS orders ("
        "order_id INTEGER PRIMARY KEY,"
        "customer_id INTEGER NOT NULL,"
        "total_amount REAL NOT NULL,"
        "order_date TEXT NOT NULL,"
        "batch_no REAL NOT NULL,"
        "FOREIGN KEY(customer_id) REFERENCES customers(customer_id)"
        ");"
        "CREATE TABLE IF NOT EXISTS order_medicines ("
        "order_id INTEGER NOT NULL,"
        "medicine_id INTEGER NOT NULL,"
        "FOREIGN KEY(order_id) REFERENCES orders(order_id),"
        "FOREIGN KEY(medicine_id) REFERENCES medicines(medicine_id)"
        ");"
        "CREATE TABLE IF NOT EXISTS payments ("
        "payment_id INTEGER PRIMARY KEY,"
        "order_id INTEGER NOT NULL,"
        "amount REAL NOT NULL,"
        "method TEXT NOT NULL,"
        "payment_date TEXT NOT NULL,"
        "status TEXT NOT NULL,"
        "FOREIGN KEY(order_id) REFERENCES orders(order_id)"
        ");";

    return execute(schema);
}

int Database::getNextId(const std::string& table, const std::string& column) {
    std::string query = "SELECT IFNULL(MAX(" + column + "), 0) + 1 FROM " + table + ";";
    sqlite3_stmt* stmt = nullptr;
    int nextId = 1;
    if (sqlite3_prepare_v2(db, query.c_str(), -1, &stmt, nullptr) == SQLITE_OK) {
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            nextId = sqlite3_column_int(stmt, 0);
        }
    }
    sqlite3_finalize(stmt);
    return nextId;
}

int Database::getNextOrderId() {
    return getNextId("orders", "order_id");
}

int Database::getNextPaymentId() {
    return getNextId("payments", "payment_id");
}

bool Database::addMedicine(const Medicine& med) {
    const char* sql = "INSERT INTO medicines (medicine_id, name, brand, price, stock, expiry_date) VALUES (?, ?, ?, ?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }
    sqlite3_bind_int(stmt, 1, med.getMedicineId());
    sqlite3_bind_text(stmt, 2, med.getName().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, med.getBrand().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_double(stmt, 4, med.getPrice());
    sqlite3_bind_int(stmt, 5, med.getStock());
    sqlite3_bind_text(stmt, 6, med.getExpiryDate().c_str(), -1, SQLITE_TRANSIENT);

    bool success = sqlite3_step(stmt) == SQLITE_DONE;
    sqlite3_finalize(stmt);
    return success;
}

bool Database::updateMedicineStock(int medicineId, int newStock) {
    const char* sql = "UPDATE medicines SET stock = ? WHERE medicine_id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }
    sqlite3_bind_int(stmt, 1, newStock);
    sqlite3_bind_int(stmt, 2, medicineId);
    bool success = sqlite3_step(stmt) == SQLITE_DONE;
    sqlite3_finalize(stmt);
    return success;
}

bool Database::addCustomer(const Customer& cust) {
    const char* sql = "INSERT INTO customers (customer_id, name, phone, email) VALUES (?, ?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }
    sqlite3_bind_int(stmt, 1, cust.getCustomerId());
    sqlite3_bind_text(stmt, 2, cust.getName().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, cust.getPhone().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 4, cust.getEmail().c_str(), -1, SQLITE_TRANSIENT);
    bool success = sqlite3_step(stmt) == SQLITE_DONE;
    sqlite3_finalize(stmt);
    return success;
}

bool Database::addOrder(const Order& order) {
    const char* sql = "INSERT INTO orders (order_id, customer_id, total_amount, order_date, batch_no) VALUES (?, ?, ?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }
    sqlite3_bind_int(stmt, 1, order.getOrderId());
    sqlite3_bind_int(stmt, 2, order.getCustomer()->getCustomerId());
    sqlite3_bind_double(stmt, 3, order.getTotalAmount());
    sqlite3_bind_text(stmt, 4, order.getOrderDate().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_double(stmt, 5, order.getBatchNo());
    bool success = sqlite3_step(stmt) == SQLITE_DONE;
    sqlite3_finalize(stmt);
    return success;
}

bool Database::addOrderMedicine(int orderId, int medicineId) {
    const char* sql = "INSERT INTO order_medicines (order_id, medicine_id) VALUES (?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }
    sqlite3_bind_int(stmt, 1, orderId);
    sqlite3_bind_int(stmt, 2, medicineId);
    bool success = sqlite3_step(stmt) == SQLITE_DONE;
    sqlite3_finalize(stmt);
    return success;
}

bool Database::addPayment(const Payment& payment) {
    const char* sql = "INSERT INTO payments (payment_id, order_id, amount, method, payment_date, status) VALUES (?, ?, ?, ?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }
    sqlite3_bind_int(stmt, 1, payment.getPaymentId());
    sqlite3_bind_int(stmt, 2, payment.getOrder()->getOrderId());
    sqlite3_bind_double(stmt, 3, payment.getAmount());
    sqlite3_bind_text(stmt, 4, payment.getPaymentMethod().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 5, payment.getPaymentDate().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 6, payment.getStatus().c_str(), -1, SQLITE_TRANSIENT);
    bool success = sqlite3_step(stmt) == SQLITE_DONE;
    sqlite3_finalize(stmt);
    return success;
}

std::vector<Medicine*> Database::loadMedicines() {
    std::vector<Medicine*> medicines;
    const char* sql = "SELECT medicine_id, name, brand, price, stock, expiry_date FROM medicines;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return medicines;
    }
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int id = sqlite3_column_int(stmt, 0);
        std::string name(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1)));
        std::string brand(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2)));
        double price = sqlite3_column_double(stmt, 3);
        int stock = sqlite3_column_int(stmt, 4);
        std::string expiry(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5)));
        medicines.push_back(new Medicine(id, name, brand, price, stock, expiry));
    }
    sqlite3_finalize(stmt);
    return medicines;
}

std::vector<Customer*> Database::loadCustomers() {
    std::vector<Customer*> customers;
    const char* sql = "SELECT customer_id, name, phone, email FROM customers;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return customers;
    }
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int id = sqlite3_column_int(stmt, 0);
        std::string name(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1)));
        std::string phone(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2)));
        std::string email(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3)));
        customers.push_back(new Customer(id, name, phone, email));
    }
    sqlite3_finalize(stmt);
    return customers;
}

Medicine* Database::findMedicineById(int medicineId, const std::vector<Medicine*>& inventory) {
    for (auto* med : inventory) {
        if (med->getMedicineId() == medicineId) {
            return med;
        }
    }
    return nullptr;
}

void Database::loadOrdersForCustomer(Customer* cust, const std::vector<Medicine*>& inventory) {
    const char* sql = "SELECT order_id, total_amount, order_date, batch_no FROM orders WHERE customer_id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return;
    }
    sqlite3_bind_int(stmt, 1, cust->getCustomerId());
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int orderId = sqlite3_column_int(stmt, 0);
        double total = sqlite3_column_double(stmt, 1);
        std::string orderDate(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2)));
        double batchNo = sqlite3_column_double(stmt, 3);

        Order* order = new Order(orderId, cust, batchNo);
        order->setOrderDate(orderDate);
        order->setTotalAmount(total);

        const char* medSql = "SELECT medicine_id FROM order_medicines WHERE order_id = ?;";
        sqlite3_stmt* medStmt = nullptr;
        if (sqlite3_prepare_v2(db, medSql, -1, &medStmt, nullptr) == SQLITE_OK) {
            sqlite3_bind_int(medStmt, 1, orderId);
            while (sqlite3_step(medStmt) == SQLITE_ROW) {
                int medId = sqlite3_column_int(medStmt, 0);
                Medicine* med = findMedicineById(medId, inventory);
                if (med) {
                    order->addMedicine(med);
                }
            }
        }
        sqlite3_finalize(medStmt);

        cust->addPurchase(order);
    }
    sqlite3_finalize(stmt);
}