# Pharmacy Management System

C++ implementation with separate header and source files for each class as per the UML diagram.

## Classes Implemented
- AdminPharmacist: username, name, email, phone, manageUsers(), manageInventory(), viewReports()
- Customer: customerId, name, phone, email, purchaseHistory, register(), updateProfile()
- Order: orderId, customer, medicines, totalAmount, orderDate, batchNo, placeOrder(), cancelOrder(), viewOrderDetails()
- Medicine: medicineId, name, brand, price, stock, expiryDate, addMedicine(), updateStock(), checkExpiry()
- Payment: paymentId, order, amount, paymentMethod, paymentDate, status, processPayment(), refundPayment()

## How to Compile and Run (SQLite Enabled)
1. Download `sqlite3.c` and `sqlite3.h` into the project folder (https://www.sqlite.org/download.html).
2. Run: `g++ -std=c++11 *.cpp sqlite3.c -o pharmacy_system.exe`
3. Run: `./pharmacy_system.exe`

The system now persists medicines, customers, orders, order items, and payments into `pharmacy.db`.
On startup, it loads all medicines and customers (including their orders) from the database.

Note: HTML entities in code (&amp; for &) may need replacement for compilation; manual fix or use VSCode find/replace.

C:\Users\Khairkar\Downloads\AdminPharmacist>gcc -c sqlite3.c -DSQLITE_OS_WIN=1 -D_WIN32_WINNT=0x0600

C:\Users\Khairkar\Downloads\AdminPharmacist>g++ -std=c++11 *.cpp sqlite3.o -o pharmacy_system.exe