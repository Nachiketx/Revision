#include "Medicine.h"

Medicine::Medicine(int id, const std::string & n, const std::string & b, double p, int s, const std::string & exp)
    : medicineId(id), name(n), brand(b), price(p), stock(s), expiryDate(exp) {}

Medicine::~Medicine() {}

int Medicine::getMedicineId() const { return medicineId; }
std::string Medicine::getName() const { return name; }
std::string Medicine::getBrand() const { return brand; }
double Medicine::getPrice() const { return price; }
int Medicine::getStock() const { return stock; }
std::string Medicine::getExpiryDate() const { return expiryDate; }

void Medicine::addMedicine() {
    std::cout << "Medicine added: " << name << " (ID: " << medicineId << ")" << std::endl;
}

void Medicine::updateStock(int newStock) {
    if (newStock >= 0) {
        stock = newStock;
        std::cout << "Stock updated for " << name << " to " << stock << std::endl;
    } else {
        std::cout << "Invalid stock value!" << std::endl;
    }
}

bool Medicine::checkExpiry(const std::string & currentDate) const {
    // Simple string comparison assuming YYYY-MM-DD format
    if (expiryDate < currentDate) {
        std::cout << name << " is expired!" << std::endl;
        return false;
    }
    return true;
}

void Medicine::display() const {
    std::cout << "Medicine ID: " << medicineId << ", Name: " << name
              << ", Brand: " << brand << ", Price: $" << price
              << ", Stock: " << stock << ", Expiry: " << expiryDate << std::endl;
}
