package com.example.krazyStuff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KrazyStuffApplicationTests {

	@Test
	void contextLoads() {
	}

}
