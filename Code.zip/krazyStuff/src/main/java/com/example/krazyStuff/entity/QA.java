package com.example.krazyStuff.entity;

public class QA {
    
     public String question;
    public String answer;
    public String getQuestion() {
        return question;
    }
    public void setQuestion(String question) {
        this.question = question;
    }
    public String getAnswer() {
        return answer;
    }
    public void setAnswer(String answer) {
        this.answer = answer;
    }
    public QA(String question, String answer) {
        this.question = question;
        this.answer = answer;
    }


}
