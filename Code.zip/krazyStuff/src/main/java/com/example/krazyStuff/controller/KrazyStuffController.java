package com.example.krazyStuff.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.krazyStuff.entity.QA;

// @CrossOrigin(origins="https://www.hackerrank.com/")
@CrossOrigin(origins="https://start.spring.io/")
@RestController
public class KrazyStuffController {

@GetMapping
public List<QA> getMethodName() {

    List<QA> data = List.of(
        new QA("hi soumili", "Bokachoda"),
        new QA("Spring Boot?", "kya be bhawde"),
        new QA("What is React?", "A library for building UI."),
        new QA("What is 2 + 2?", "4")
        // add as many as you want — hundreds, even thousands
    );

    return data;
}

    
}

