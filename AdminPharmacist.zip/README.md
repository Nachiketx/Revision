# Pharmacy Management System

C++ implementation with separate header and source files for each class as per the UML diagram.

## Classes Implemented
- AdminPharmacist: username, name, email, phone, manageUsers(), manageInventory(), viewReports()
- Customer: customerId, name, phone, email, purchaseHistory, register(), updateProfile()
- Order: orderId, customer, medicines, totalAmount, orderDate, batchNo, placeOrder(), cancelOrder(), viewOrderDetails()
- Medicine: medicineId, name, brand, price, stock, expiryDate, addMedicine(), updateStock(), checkExpiry()
- Payment: paymentId, order, amount, paymentMethod, paymentDate, status, processPayment(), refundPayment()

## How to Compile and Run
1. Ensure g++ is installed.
2. Run: `g++ -std=c++11 *.cpp -o pharmacy_system.exe`
3. Run: `./pharmacy_system.exe`

The main.cpp demonstrates full functionality: admin manages inventory, customer registers and places order, payment processed, reports viewed.

Note: HTML entities in code (&amp; for &) may need replacement for compilation; manual fix or use VSCode find/replace.

