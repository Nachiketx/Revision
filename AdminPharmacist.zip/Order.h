#ifndef ORDER_H
#define ORDER_H

#include <vector>
#include <string>
#include "Customer.h"
#include "Medicine.h"
#include "Payment.h"

class Customer;
class Medicine;
class Payment;

class Order {
private:
    int orderId;
    Customer* customer;
    std::vector<Medicine*> medicines;
    double totalAmount;
    std::string orderDate;  // Simplified
    double batchNo;  // As per diagram, float
    Payment* payment;  // Optional association

public:
    Order(int id, Customer* cust, double batch);
    ~Order();

    int getOrderId() const;
    Customer* getCustomer() const;
    const std::vector<Medicine*>& getMedicines() const;
    double getTotalAmount() const;
    std::string getOrderDate() const;
    double getBatchNo() const;

    void placeOrder();
    void cancelOrder();
    void viewOrderDetails() const;
    void addMedicine(Medicine* med);
    void calculateTotal();

    void setPayment(Payment* p);
};

#endif
