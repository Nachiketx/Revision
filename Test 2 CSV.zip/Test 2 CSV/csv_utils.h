#pragma once

#include <string>
#include <vector>

std::vector<std::string> splitCsvLine(const std::string &line);
std::string joinCsvLine(const std::vector<std::string> &fields);
bool ensureFileHasHeader(const std::string &path, const std::string &headerLine);
std::vector<std::vector<std::string>> readCsv(const std::string &path, bool skipHeader = true);
bool writeCsv(const std::string &path, const std::string &headerLine,
              const std::vector<std::vector<std::string>> &rows);

int nextIdFromRows(const std::vector<std::vector<std::string>> &rows);
