#pragma once

#include "models.h"

#include <string>
#include <vector>

class InventoryService {
public:
    InventoryService(const std::string &medicineFile, const std::string &batchFile);

    Medicine addMedicine(const Medicine &medicine);
    bool updateMedicine(const Medicine &medicine);
    bool deleteMedicine(int medicineId);
    std::vector<Medicine> listMedicines() const;
    std::vector<Medicine> searchMedicine(const std::string &keyword) const;

    StockBatch addBatch(const StockBatch &batch);
    bool updateBatch(const StockBatch &batch);
    bool deleteBatch(int batchId);
    std::vector<StockBatch> listBatches() const;
    std::vector<StockBatch> listBatchesByMedicine(int medicineId) const;

    bool updateStock(int batchId, int newQuantity);
    std::vector<StockBatch> checkExpiry(int daysThreshold) const;
    std::vector<StockBatch> lowStock(int threshold) const;

private:
    std::string medicineFile_;
    std::string batchFile_;

    Medicine toMedicine(const std::vector<std::string> &row) const;
    std::vector<std::string> fromMedicine(const Medicine &medicine) const;

    StockBatch toBatch(const std::vector<std::string> &row) const;
    std::vector<std::string> fromBatch(const StockBatch &batch) const;
};
