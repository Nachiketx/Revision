#include "inventory_service.h"
#include "order_service.h"
#include "payment_service.h"
#include "report_service.h"
#include "user_service.h"

#include <iomanip>
#include <iostream>
#include <limits>

namespace {
void clearInput() {
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

std::string readLine(const std::string &prompt) {
    std::string value;
    std::cout << prompt;
    std::getline(std::cin, value);
    return value;
}

int readInt(const std::string &prompt) {
    int value{};
    while (true) {
        std::cout << prompt;
        if (std::cin >> value) {
            clearInput();
            return value;
        }
        clearInput();
        std::cout << "Invalid number. Try again.\n";
    }
}

double readDouble(const std::string &prompt) {
    double value{};
    while (true) {
        std::cout << prompt;
        if (std::cin >> value) {
            clearInput();
            return value;
        }
        clearInput();
        std::cout << "Invalid amount. Try again.\n";
    }
}

bool readBool(const std::string &prompt) {
    while (true) {
        std::string value = readLine(prompt + " (y/n): ");
        if (value == "y" || value == "Y") {
            return true;
        }
        if (value == "n" || value == "N") {
            return false;
        }
        std::cout << "Please enter y or n.\n";
    }
}

std::string todayDate() {
    std::time_t t = std::time(nullptr);
    std::tm tm{};
#if defined(__unix__) || defined(__APPLE__)
    localtime_r(&t, &tm);
#else
    std::tm *timeInfo = std::localtime(&t);
    if (timeInfo) {
        tm = *timeInfo;
    }
#endif
    std::ostringstream out;
    out << std::put_time(&tm, "%Y-%m-%d");
    return out.str();
}

void printReceipt(const OrderReceipt &receipt) {
    std::cout << "\n==== Pharmacy Receipt ====\n";
    std::cout << "Order ID: " << receipt.orderId << "\n";
    std::cout << "Customer: " << receipt.customerName << " (" << receipt.customerPhone << ")\n";
    std::cout << "Order Date: " << receipt.orderDate << "\n";
    std::cout << "----------------------------------------\n";
    std::cout << std::left << std::setw(18) << "Medicine" << std::setw(10) << "Batch"
              << std::setw(8) << "Qty" << std::setw(10) << "Price" << "Total\n";
    for (const auto &item : receipt.items) {
        std::cout << std::left << std::setw(18) << item.medicineName << std::setw(10) << item.batchNo
                  << std::setw(8) << item.quantity << std::setw(10) << std::fixed << std::setprecision(2)
                  << item.unitPrice << item.lineTotal << "\n";
    }
    std::cout << "----------------------------------------\n";
    std::cout << "Total Amount: " << std::fixed << std::setprecision(2) << receipt.totalAmount << "\n";
    std::cout << "============================\n";
}

void listMedicines(const std::vector<Medicine> &medicines) {
    std::cout << std::left << std::setw(5) << "ID" << std::setw(12) << "Category" << std::setw(20) << "Name"
              << std::setw(15) << "Brand" << std::setw(10) << "Price" << "Rx?\n";
    for (const auto &medicine : medicines) {
        std::cout << std::left << std::setw(5) << medicine.medicineId << std::setw(12) << medicine.category
                  << std::setw(20) << medicine.name << std::setw(15) << medicine.brand << std::setw(10)
                  << std::fixed << std::setprecision(2) << medicine.price << (medicine.isPrescriptionRequired ? "Yes" : "No")
                  << "\n";
    }
}

void listBatches(const std::vector<StockBatch> &batches) {
    std::cout << std::left << std::setw(6) << "Batch" << std::setw(6) << "MedID" << std::setw(12) << "BatchNo"
              << std::setw(12) << "Expiry" << "Qty\n";
    for (const auto &batch : batches) {
        std::cout << std::left << std::setw(6) << batch.batchId << std::setw(6) << batch.medicineId
                  << std::setw(12) << batch.batchNo << std::setw(12) << batch.expiryDate << batch.quantityAvailable
                  << "\n";
    }
}
} // namespace

int main() {
    InventoryService inventory("medicines.csv", "batches.csv");
    UserService users("users.csv", "customers.csv");
    OrderService orders("orders.csv", "order_items.csv", "customers.csv", "medicines.csv", "batches.csv");
    PaymentService payments("payments.csv", "orders.csv");
    ReportService reports("orders.csv", "payments.csv", "customers.csv");

    bool running = true;
    while (running) {
        std::cout << "\n==== Pharmacy Management ===="
                  << "\n1. Inventory"
                  << "\n2. Customers"
                  << "\n3. Orders"
                  << "\n4. Payments"
                  << "\n5. Reports"
                  << "\n6. Notices"
                  << "\n0. Exit\n";

        int choice = readInt("Select option: ");
        switch (choice) {
        case 1: {
            bool invMenu = true;
            while (invMenu) {
                std::cout << "\n-- Inventory --"
                          << "\n1. Add Medicine"
                          << "\n2. Update Medicine"
                          << "\n3. Delete Medicine"
                          << "\n4. List Medicines"
                          << "\n5. Search Medicine"
                          << "\n6. Add Batch"
                          << "\n7. Update Batch"
                          << "\n8. Delete Batch"
                          << "\n9. List Batches"
                          << "\n0. Back\n";
                int invChoice = readInt("Select option: ");
                switch (invChoice) {
                case 1: {
                    Medicine med;
                    med.category = readLine("Category: ");
                    med.name = readLine("Name: ");
                    med.brand = readLine("Brand: ");
                    med.price = readDouble("Price: ");
                    med.isPrescriptionRequired = readBool("Prescription required");
                    auto stored = inventory.addMedicine(med);
                    std::cout << "Added medicine with ID " << stored.medicineId << "\n";
                    break;
                }
                case 2: {
                    Medicine med;
                    med.medicineId = readInt("Medicine ID: ");
                    med.category = readLine("Category: ");
                    med.name = readLine("Name: ");
                    med.brand = readLine("Brand: ");
                    med.price = readDouble("Price: ");
                    med.isPrescriptionRequired = readBool("Prescription required");
                    if (inventory.updateMedicine(med)) {
                        std::cout << "Medicine updated.\n";
                    } else {
                        std::cout << "Medicine not found.\n";
                    }
                    break;
                }
                case 3: {
                    int id = readInt("Medicine ID to delete: ");
                    if (inventory.deleteMedicine(id)) {
                        std::cout << "Medicine deleted.\n";
                    } else {
                        std::cout << "Medicine not found.\n";
                    }
                    break;
                }
                case 4: {
                    listMedicines(inventory.listMedicines());
                    break;
                }
                case 5: {
                    std::string keyword = readLine("Search keyword: ");
                    listMedicines(inventory.searchMedicine(keyword));
                    break;
                }
                case 6: {
                    StockBatch batch;
                    batch.medicineId = readInt("Medicine ID: ");
                    batch.batchNo = readLine("Batch No: ");
                    batch.expiryDate = readLine("Expiry Date (YYYY-MM-DD): ");
                    batch.quantityAvailable = readInt("Quantity: ");
                    auto stored = inventory.addBatch(batch);
                    std::cout << "Added batch with ID " << stored.batchId << "\n";
                    break;
                }
                case 7: {
                    StockBatch batch;
                    batch.batchId = readInt("Batch ID: ");
                    batch.medicineId = readInt("Medicine ID: ");
                    batch.batchNo = readLine("Batch No: ");
                    batch.expiryDate = readLine("Expiry Date (YYYY-MM-DD): ");
                    batch.quantityAvailable = readInt("Quantity: ");
                    if (inventory.updateBatch(batch)) {
                        std::cout << "Batch updated.\n";
                    } else {
                        std::cout << "Batch not found.\n";
                    }
                    break;
                }
                case 8: {
                    int id = readInt("Batch ID to delete: ");
                    if (inventory.deleteBatch(id)) {
                        std::cout << "Batch deleted.\n";
                    } else {
                        std::cout << "Batch not found.\n";
                    }
                    break;
                }
                case 9: {
                    listBatches(inventory.listBatches());
                    break;
                }
                case 0:
                    invMenu = false;
                    break;
                default:
                    std::cout << "Invalid option.\n";
                    break;
                }
            }
            break;
        }
        case 2: {
            bool custMenu = true;
            while (custMenu) {
                std::cout << "\n-- Customers --"
                          << "\n1. Add Customer"
                          << "\n2. Update Customer"
                          << "\n3. List Customers"
                          << "\n0. Back\n";
                int custChoice = readInt("Select option: ");
                switch (custChoice) {
                case 1: {
                    Customer customer;
                    customer.name = readLine("Name: ");
                    customer.phone = readLine("Phone: ");
                    customer.email = readLine("Email: ");
                    customer.address = readLine("Address: ");
                    auto stored = users.addCustomer(customer);
                    std::cout << "Customer added with ID " << stored.customerId << "\n";
                    break;
                }
                case 2: {
                    Customer customer;
                    customer.customerId = readInt("Customer ID: ");
                    customer.name = readLine("Name: ");
                    customer.phone = readLine("Phone: ");
                    customer.email = readLine("Email: ");
                    customer.address = readLine("Address: ");
                    if (users.updateCustomer(customer)) {
                        std::cout << "Customer updated.\n";
                    } else {
                        std::cout << "Customer not found.\n";
                    }
                    break;
                }
                case 3: {
                    auto customers = users.listCustomers();
                    std::cout << std::left << std::setw(5) << "ID" << std::setw(20) << "Name" << std::setw(15)
                              << "Phone" << std::setw(20) << "Email" << "Address\n";
                    for (const auto &cust : customers) {
                        std::cout << std::left << std::setw(5) << cust.customerId << std::setw(20) << cust.name
                                  << std::setw(15) << cust.phone << std::setw(20) << cust.email << cust.address << "\n";
                    }
                    break;
                }
                case 0:
                    custMenu = false;
                    break;
                default:
                    std::cout << "Invalid option.\n";
                    break;
                }
            }
            break;
        }
        case 3: {
            bool orderMenu = true;
            while (orderMenu) {
                std::cout << "\n-- Orders --"
                          << "\n1. Place Order"
                          << "\n2. Cancel Order"
                          << "\n3. View Orders"
                          << "\n4. View Receipt"
                          << "\n0. Back\n";
                int orderChoice = readInt("Select option: ");
                switch (orderChoice) {
                case 1: {
                    int customerId = readInt("Customer ID: ");
                    int itemCount = readInt("Number of items: ");
                    std::vector<OrderItem> items;
                    for (int i = 0; i < itemCount; ++i) {
                        std::cout << "Item " << (i + 1) << "\n";
                        OrderItem item;
                        item.medicineId = readInt("Medicine ID: ");
                        item.batchId = readInt("Batch ID: ");
                        item.quantity = readInt("Quantity: ");
                        item.unitPrice = readDouble("Unit price: ");
                        item.lineTotal = item.unitPrice * item.quantity;
                        items.push_back(item);
                    }
                    auto order = orders.placeOrder(customerId, items, todayDate());
                    std::cout << "Order placed with ID " << order.orderId << " (Total " << order.totalAmount << ")\n";
                    OrderReceipt receipt;
                    if (orders.getReceipt(order.orderId, receipt)) {
                        printReceipt(receipt);
                    }
                    break;
                }
                case 2: {
                    int orderId = readInt("Order ID: ");
                    if (orders.cancelOrder(orderId)) {
                        std::cout << "Order cancelled.\n";
                    } else {
                        std::cout << "Order not found.\n";
                    }
                    break;
                }
                case 3: {
                    auto orderList = orders.listOrders();
                    std::cout << std::left << std::setw(6) << "ID" << std::setw(10) << "CustID" << std::setw(12)
                              << "Date" << std::setw(12) << "Status" << "Total\n";
                    for (const auto &order : orderList) {
                        std::cout << std::left << std::setw(6) << order.orderId << std::setw(10) << order.customerId
                                  << std::setw(12) << order.orderDate << std::setw(12)
                                  << (order.status == OrderStatus::CANCELLED ? "CANCELLED" : "CONFIRMED")
                                  << std::fixed << std::setprecision(2) << order.totalAmount << "\n";
                    }
                    break;
                }
                case 4: {
                    int orderId = readInt("Order ID: ");
                    OrderReceipt receipt;
                    if (orders.getReceipt(orderId, receipt)) {
                        printReceipt(receipt);
                    } else {
                        std::cout << "Order not found.\n";
                    }
                    break;
                }
                case 0:
                    orderMenu = false;
                    break;
                default:
                    std::cout << "Invalid option.\n";
                    break;
                }
            }
            break;
        }
        case 4: {
            bool payMenu = true;
            while (payMenu) {
                std::cout << "\n-- Payments --"
                          << "\n1. Process Payment"
                          << "\n2. Refund Payment"
                          << "\n3. View Payments"
                          << "\n0. Back\n";
                int payChoice = readInt("Select option: ");
                switch (payChoice) {
                case 1: {
                    Payment payment;
                    payment.orderId = readInt("Order ID: ");
                    payment.amount = readDouble("Amount: ");
                    payment.paymentDate = todayDate();
                    payment.status = PaymentStatus::SUCCESS;
                    payment.transactionRef = readLine("Transaction Ref: ");
                    auto stored = payments.processPayment(payment);
                    std::cout << "Payment recorded with ID " << stored.paymentId << "\n";
                    break;
                }
                case 2: {
                    int paymentId = readInt("Payment ID: ");
                    std::string refundRef = readLine("Refund Ref: ");
                    if (payments.refundPayment(paymentId, refundRef)) {
                        std::cout << "Payment refunded.\n";
                    } else {
                        std::cout << "Payment not found.\n";
                    }
                    break;
                }
                case 3: {
                    auto paymentList = payments.listPayments();
                    std::cout << std::left << std::setw(6) << "ID" << std::setw(8) << "Order" << std::setw(10)
                              << "Amount" << std::setw(12) << "Date" << std::setw(10) << "Status" << "Ref\n";
                    for (const auto &payment : paymentList) {
                        std::cout << std::left << std::setw(6) << payment.paymentId << std::setw(8) << payment.orderId
                                  << std::setw(10) << std::fixed << std::setprecision(2) << payment.amount
                                  << std::setw(12) << payment.paymentDate << std::setw(10)
                                  << (payment.status == PaymentStatus::FAILED ? "FAILED" : "SUCCESS") << payment.transactionRef
                                  << "\n";
                    }
                    break;
                }
                case 0:
                    payMenu = false;
                    break;
                default:
                    std::cout << "Invalid option.\n";
                    break;
                }
            }
            break;
        }
        case 5: {
            std::cout << "\n-- Reports --\n";
            auto orderList = reports.viewOrders();
            std::cout << "Orders: " << orderList.size() << "\n";
            auto paymentList = reports.viewPayments();
            std::cout << "Payments: " << paymentList.size() << "\n";
            auto customerList = reports.viewCustomers();
            std::cout << "Customers: " << customerList.size() << "\n";
            break;
        }
        case 6: {
            std::cout << "\n-- Notices --\n";
            auto expiring = inventory.checkExpiry(14);
            std::cout << "Expiring within 14 days: " << expiring.size() << "\n";
            listBatches(expiring);
            auto low = inventory.lowStock(10);
            std::cout << "Low stock (<=10): " << low.size() << "\n";
            listBatches(low);
            break;
        }
        case 0:
            running = false;
            break;
        default:
            std::cout << "Invalid option.\n";
            break;
        }
    }

    std::cout << "Goodbye!\n";
    return 0;
}
