#include "payment_service.h"

#include "csv_utils.h"

#include <algorithm>

namespace {
int toInt(const std::string &value) {
    return std::stoi(value);
}

double toDouble(const std::string &value) {
    return std::stod(value);
}

std::string statusToString(PaymentStatus status) {
    return status == PaymentStatus::FAILED ? "FAILED" : "SUCCESS";
}

PaymentStatus statusFromString(const std::string &value) {
    return value == "FAILED" ? PaymentStatus::FAILED : PaymentStatus::SUCCESS;
}
} // namespace

PaymentService::PaymentService(const std::string &paymentFile, const std::string &orderFile)
    : paymentFile_(paymentFile), orderFile_(orderFile) {
    ensureFileHasHeader(paymentFile_, "paymentId,orderId,amount,paymentDate,status,transactionRef");
    ensureFileHasHeader(orderFile_, "orderId,customerId,orderDate,status,totalAmount");
}

Payment PaymentService::processPayment(const Payment &payment) {
    auto rows = readCsv(paymentFile_);
    Payment stored = payment;
    stored.paymentId = nextIdFromRows(rows);
    rows.push_back(fromPayment(stored));
    writeCsv(paymentFile_, "paymentId,orderId,amount,paymentDate,status,transactionRef", rows);
    return stored;
}

bool PaymentService::refundPayment(int paymentId, const std::string &refundRef) {
    auto rows = readCsv(paymentFile_);
    bool updated = false;
    for (auto &row : rows) {
        if (!row.empty() && toInt(row[0]) == paymentId) {
            if (row.size() < 6) {
                row.resize(6);
            }
            row[4] = statusToString(PaymentStatus::FAILED);
            row[5] = refundRef;
            updated = true;
            break;
        }
    }
    if (updated) {
        writeCsv(paymentFile_, "paymentId,orderId,amount,paymentDate,status,transactionRef", rows);
    }
    return updated;
}

std::vector<Payment> PaymentService::listPayments() const {
    auto rows = readCsv(paymentFile_);
    std::vector<Payment> payments;
    for (const auto &row : rows) {
        if (row.size() >= 6) {
            payments.push_back(toPayment(row));
        }
    }
    return payments;
}

bool PaymentService::getPaymentForOrder(int orderId, Payment &payment) const {
    auto payments = listPayments();
    auto it = std::find_if(payments.begin(), payments.end(), [&](const Payment &entry) {
        return entry.orderId == orderId;
    });
    if (it == payments.end()) {
        return false;
    }
    payment = *it;
    return true;
}

Payment PaymentService::toPayment(const std::vector<std::string> &row) const {
    Payment payment;
    payment.paymentId = toInt(row[0]);
    payment.orderId = toInt(row[1]);
    payment.amount = toDouble(row[2]);
    payment.paymentDate = row[3];
    payment.status = statusFromString(row[4]);
    payment.transactionRef = row[5];
    return payment;
}

std::vector<std::string> PaymentService::fromPayment(const Payment &payment) const {
    return {
        std::to_string(payment.paymentId),
        std::to_string(payment.orderId),
        std::to_string(payment.amount),
        payment.paymentDate,
        statusToString(payment.status),
        payment.transactionRef};
}
