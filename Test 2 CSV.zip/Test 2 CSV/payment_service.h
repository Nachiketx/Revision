#pragma once
#include<bits/stdc++.h>
#include "models.h"

#include <string>
#include <vector>

class PaymentService {
public:
    PaymentService(const std::string &paymentFile, const std::string &orderFile);

    Payment processPayment(const Payment &payment);
    bool refundPayment(int paymentId, const std::string &refundRef);
    std::vector<Payment> listPayments() const;
    bool getPaymentForOrder(int orderId, Payment &payment) const;

private:
    std::string paymentFile_;
    std::string orderFile_;

    Payment toPayment(const std::vector<std::string> &row) const;
    std::vector<std::string> fromPayment(const Payment &payment) const;
};
