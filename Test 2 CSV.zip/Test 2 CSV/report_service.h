#pragma once

#include "models.h"

#include <string>
#include <vector>

class ReportService {
public:
    ReportService(const std::string &orderFile,
                  const std::string &paymentFile,
                  const std::string &customerFile);

    std::vector<Order> viewOrders() const;
    std::vector<Payment> viewPayments() const;
    std::vector<Customer> viewCustomers() const;

private:
    std::string orderFile_;
    std::string paymentFile_;
    std::string customerFile_;
};
