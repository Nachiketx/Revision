#include "report_service.h"

#include "csv_utils.h"

namespace {
int toInt(const std::string &value) {
    return std::stoi(value);
}

double toDouble(const std::string &value) {
    return std::stod(value);
}

OrderStatus statusFromString(const std::string &value) {
    return value == "CANCELLED" ? OrderStatus::CANCELLED : OrderStatus::CONFIRMED;
}

PaymentStatus paymentStatusFromString(const std::string &value) {
    return value == "FAILED" ? PaymentStatus::FAILED : PaymentStatus::SUCCESS;
}
} // namespace

ReportService::ReportService(const std::string &orderFile,
                             const std::string &paymentFile,
                             const std::string &customerFile)
    : orderFile_(orderFile), paymentFile_(paymentFile), customerFile_(customerFile) {
    ensureFileHasHeader(orderFile_, "orderId,customerId,orderDate,status,totalAmount");
    ensureFileHasHeader(paymentFile_, "paymentId,orderId,amount,paymentDate,status,transactionRef");
    ensureFileHasHeader(customerFile_, "customerId,name,phone,email,address");
}

std::vector<Order> ReportService::viewOrders() const {
    auto rows = readCsv(orderFile_);
    std::vector<Order> orders;
    for (const auto &row : rows) {
        if (row.size() < 5) {
            continue;
        }
        Order order;
        order.orderId = toInt(row[0]);
        order.customerId = toInt(row[1]);
        order.orderDate = row[2];
        order.status = statusFromString(row[3]);
        order.totalAmount = toDouble(row[4]);
        orders.push_back(order);
    }
    return orders;
}

std::vector<Payment> ReportService::viewPayments() const {
    auto rows = readCsv(paymentFile_);
    std::vector<Payment> payments;
    for (const auto &row : rows) {
        if (row.size() < 6) {
            continue;
        }
        Payment payment;
        payment.paymentId = toInt(row[0]);
        payment.orderId = toInt(row[1]);
        payment.amount = toDouble(row[2]);
        payment.paymentDate = row[3];
        payment.status = paymentStatusFromString(row[4]);
        payment.transactionRef = row[5];
        payments.push_back(payment);
    }
    return payments;
}

std::vector<Customer> ReportService::viewCustomers() const {
    auto rows = readCsv(customerFile_);
    std::vector<Customer> customers;
    for (const auto &row : rows) {
        if (row.size() < 5) {
            continue;
        }
        Customer customer;
        customer.customerId = toInt(row[0]);
        customer.name = row[1];
        customer.phone = row[2];
        customer.email = row[3];
        customer.address = row[4];
        customers.push_back(customer);
    }
    return customers;
}
