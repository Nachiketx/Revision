#include "inventory_service.h"

#include "csv_utils.h"

#include <algorithm>
#include <chrono>
#include <iomanip>
#include <sstream>

namespace {
int toInt(const std::string &value) {
    return std::stoi(value);
}

double toDouble(const std::string &value) {
    return std::stod(value);
}

std::string toLower(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) { return std::tolower(c); });
    return value;
}

std::chrono::system_clock::time_point parseDate(const std::string &date) {
    std::tm tm{};
    std::istringstream ss(date);
    ss >> std::get_time(&tm, "%Y-%m-%d");
    tm.tm_hour = 0;
    tm.tm_min = 0;
    tm.tm_sec = 0;
    return std::chrono::system_clock::from_time_t(std::mktime(&tm));
}
} // namespace

InventoryService::InventoryService(const std::string &medicineFile, const std::string &batchFile)
    : medicineFile_(medicineFile), batchFile_(batchFile) {
    ensureFileHasHeader(medicineFile_, "medicineId,category,name,brand,price,isPrescriptionRequired");
    ensureFileHasHeader(batchFile_, "batchId,medicineId,batchNo,expiryDate,quantityAvailable");
}

Medicine InventoryService::addMedicine(const Medicine &medicine) {
    auto rows = readCsv(medicineFile_);
    Medicine stored = medicine;
    stored.medicineId = nextIdFromRows(rows);
    rows.push_back(fromMedicine(stored));
    writeCsv(medicineFile_, "medicineId,category,name,brand,price,isPrescriptionRequired", rows);
    return stored;
}

bool InventoryService::updateMedicine(const Medicine &medicine) {
    auto rows = readCsv(medicineFile_);
    bool updated = false;
    for (auto &row : rows) {
        if (!row.empty() && toInt(row[0]) == medicine.medicineId) {
            row = fromMedicine(medicine);
            updated = true;
            break;
        }
    }
    if (updated) {
        writeCsv(medicineFile_, "medicineId,category,name,brand,price,isPrescriptionRequired", rows);
    }
    return updated;
}

bool InventoryService::deleteMedicine(int medicineId) {
    auto rows = readCsv(medicineFile_);
    auto original = rows.size();
    rows.erase(std::remove_if(rows.begin(), rows.end(), [&](const auto &row) {
                   return !row.empty() && toInt(row[0]) == medicineId;
               }),
               rows.end());
    if (rows.size() != original) {
        writeCsv(medicineFile_, "medicineId,category,name,brand,price,isPrescriptionRequired", rows);
        return true;
    }
    return false;
}

std::vector<Medicine> InventoryService::listMedicines() const {
    auto rows = readCsv(medicineFile_);
    std::vector<Medicine> medicines;
    for (const auto &row : rows) {
        if (row.size() >= 6) {
            medicines.push_back(toMedicine(row));
        }
    }
    return medicines;
}

std::vector<Medicine> InventoryService::searchMedicine(const std::string &keyword) const {
    std::string target = toLower(keyword);
    auto medicines = listMedicines();
    std::vector<Medicine> results;
    for (const auto &medicine : medicines) {
        std::string hay = toLower(medicine.name + " " + medicine.brand + " " + medicine.category);
        if (hay.find(target) != std::string::npos) {
            results.push_back(medicine);
        }
    }
    return results;
}

StockBatch InventoryService::addBatch(const StockBatch &batch) {
    auto rows = readCsv(batchFile_);
    StockBatch stored = batch;
    stored.batchId = nextIdFromRows(rows);
    rows.push_back(fromBatch(stored));
    writeCsv(batchFile_, "batchId,medicineId,batchNo,expiryDate,quantityAvailable", rows);
    return stored;
}

bool InventoryService::updateBatch(const StockBatch &batch) {
    auto rows = readCsv(batchFile_);
    bool updated = false;
    for (auto &row : rows) {
        if (!row.empty() && toInt(row[0]) == batch.batchId) {
            row = fromBatch(batch);
            updated = true;
            break;
        }
    }
    if (updated) {
        writeCsv(batchFile_, "batchId,medicineId,batchNo,expiryDate,quantityAvailable", rows);
    }
    return updated;
}

bool InventoryService::deleteBatch(int batchId) {
    auto rows = readCsv(batchFile_);
    auto original = rows.size();
    rows.erase(std::remove_if(rows.begin(), rows.end(), [&](const auto &row) {
                   return !row.empty() && toInt(row[0]) == batchId;
               }),
               rows.end());
    if (rows.size() != original) {
        writeCsv(batchFile_, "batchId,medicineId,batchNo,expiryDate,quantityAvailable", rows);
        return true;
    }
    return false;
}

std::vector<StockBatch> InventoryService::listBatches() const {
    auto rows = readCsv(batchFile_);
    std::vector<StockBatch> batches;
    for (const auto &row : rows) {
        if (row.size() >= 5) {
            batches.push_back(toBatch(row));
        }
    }
    return batches;
}

std::vector<StockBatch> InventoryService::listBatchesByMedicine(int medicineId) const {
    auto batches = listBatches();
    std::vector<StockBatch> filtered;
    for (const auto &batch : batches) {
        if (batch.medicineId == medicineId) {
            filtered.push_back(batch);
        }
    }
    return filtered;
}

bool InventoryService::updateStock(int batchId, int newQuantity) {
    auto rows = readCsv(batchFile_);
    bool updated = false;
    for (auto &row : rows) {
        if (!row.empty() && toInt(row[0]) == batchId) {
            if (row.size() < 5) {
                row.resize(5);
            }
            row[4] = std::to_string(newQuantity);
            updated = true;
            break;
        }
    }
    if (updated) {
        writeCsv(batchFile_, "batchId,medicineId,batchNo,expiryDate,quantityAvailable", rows);
    }
    return updated;
}

std::vector<StockBatch> InventoryService::checkExpiry(int daysThreshold) const {
    auto batches = listBatches();
    std::vector<StockBatch> expiring;
    auto now = std::chrono::system_clock::now();
    for (const auto &batch : batches) {
        auto expiry = parseDate(batch.expiryDate);
        auto diff = std::chrono::duration_cast<std::chrono::hours>(expiry - now).count() / 24;
        if (diff >= 0 && diff <= daysThreshold) {
            expiring.push_back(batch);
        }
    }
    return expiring;
}

std::vector<StockBatch> InventoryService::lowStock(int threshold) const {
    auto batches = listBatches();
    std::vector<StockBatch> low;
    for (const auto &batch : batches) {
        if (batch.quantityAvailable <= threshold) {
            low.push_back(batch);
        }
    }
    return low;
}

Medicine InventoryService::toMedicine(const std::vector<std::string> &row) const {
    Medicine medicine;
    medicine.medicineId = toInt(row[0]);
    medicine.category = row[1];
    medicine.name = row[2];
    medicine.brand = row[3];
    medicine.price = toDouble(row[4]);
    medicine.isPrescriptionRequired = row[5] == "1" || row[5] == "true" || row[5] == "True";
    return medicine;
}

std::vector<std::string> InventoryService::fromMedicine(const Medicine &medicine) const {
    return {
        std::to_string(medicine.medicineId),
        medicine.category,
        medicine.name,
        medicine.brand,
        std::to_string(medicine.price),
        medicine.isPrescriptionRequired ? "1" : "0"};
}

StockBatch InventoryService::toBatch(const std::vector<std::string> &row) const {
    StockBatch batch;
    batch.batchId = toInt(row[0]);
    batch.medicineId = toInt(row[1]);
    batch.batchNo = row[2];
    batch.expiryDate = row[3];
    batch.quantityAvailable = toInt(row[4]);
    return batch;
}

std::vector<std::string> InventoryService::fromBatch(const StockBatch &batch) const {
    return {
        std::to_string(batch.batchId),
        std::to_string(batch.medicineId),
        batch.batchNo,
        batch.expiryDate,
        std::to_string(batch.quantityAvailable)};
}
