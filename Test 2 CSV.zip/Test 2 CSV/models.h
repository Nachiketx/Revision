#pragma once

#include <string>
#include <vector>

enum class UserRole { ADMIN, PHARMACIST, CUSTOMER };
enum class OrderStatus { CONFIRMED, CANCELLED };
enum class PaymentStatus { SUCCESS, FAILED };

struct User {
    int userId{};
    std::string username;
    std::string email;
    std::string name;
    std::string phone;
    UserRole role{UserRole::CUSTOMER};
    std::string passwordHash;
    bool isActive{true};
};

struct Customer {
    int customerId{};
    std::string name;
    std::string phone;
    std::string email;
    std::string address;
};

struct Medicine {
    int medicineId{};
    std::string category;
    std::string name;
    std::string brand;
    double price{};
    bool isPrescriptionRequired{false};
};

struct StockBatch {
    int batchId{};
    int medicineId{};
    std::string batchNo;
    std::string expiryDate; // YYYY-MM-DD
    int quantityAvailable{};
};

struct Order {
    int orderId{};
    int customerId{};
    std::string orderDate; // YYYY-MM-DD
    OrderStatus status{OrderStatus::CONFIRMED};
    double totalAmount{};
};

struct OrderItem {
    int orderItemId{};
    int orderId{};
    int medicineId{};
    int batchId{};
    int quantity{};
    double unitPrice{};
    double lineTotal{};
};

struct Payment {
    int paymentId{};
    int orderId{};
    double amount{};
    std::string paymentDate; // YYYY-MM-DD
    PaymentStatus status{PaymentStatus::SUCCESS};
    std::string transactionRef;
};
