#pragma once

#include "models.h"

#include <string>
#include <vector>

class UserService {
public:
    UserService(const std::string &userFile, const std::string &customerFile);

    User addUser(const User &user);
    bool updateUser(const User &user);
    bool deactivateUser(int userId);
    std::vector<User> listUsers() const;
    std::vector<User> listUsersByRole(UserRole role) const;

    Customer addCustomer(const Customer &customer);
    bool updateCustomer(const Customer &customer);
    std::vector<Customer> listCustomers() const;

private:
    std::string userFile_;
    std::string customerFile_;

    User toUser(const std::vector<std::string> &row) const;
    std::vector<std::string> fromUser(const User &user) const;

    Customer toCustomer(const std::vector<std::string> &row) const;
    std::vector<std::string> fromCustomer(const Customer &customer) const;
};
