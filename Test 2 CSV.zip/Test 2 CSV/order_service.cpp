#include "order_service.h"

#include "csv_utils.h"

#include <algorithm>
#include <iomanip>
#include <sstream>

namespace {
int toInt(const std::string &value) {
    return std::stoi(value);
}

double toDouble(const std::string &value) {
    return std::stod(value);
}

std::string statusToString(OrderStatus status) {
    return status == OrderStatus::CANCELLED ? "CANCELLED" : "CONFIRMED";
}

OrderStatus statusFromString(const std::string &value) {
    return value == "CANCELLED" ? OrderStatus::CANCELLED : OrderStatus::CONFIRMED;
}
} // namespace

OrderService::OrderService(const std::string &orderFile,
                           const std::string &orderItemFile,
                           const std::string &customerFile,
                           const std::string &medicineFile,
                           const std::string &batchFile)
    : orderFile_(orderFile), orderItemFile_(orderItemFile), customerFile_(customerFile),
      medicineFile_(medicineFile), batchFile_(batchFile) {
    ensureFileHasHeader(orderFile_, "orderId,customerId,orderDate,status,totalAmount");
    ensureFileHasHeader(orderItemFile_, "orderItemId,orderId,medicineId,batchId,quantity,unitPrice,lineTotal");
    ensureFileHasHeader(customerFile_, "customerId,name,phone,email,address");
    ensureFileHasHeader(medicineFile_, "medicineId,category,name,brand,price,isPrescriptionRequired");
    ensureFileHasHeader(batchFile_, "batchId,medicineId,batchNo,expiryDate,quantityAvailable");
}

Order OrderService::placeOrder(int customerId, const std::vector<OrderItem> &items, const std::string &orderDate) {
    auto orderRows = readCsv(orderFile_);
    auto itemRows = readCsv(orderItemFile_);

    Order order;
    order.orderId = nextIdFromRows(orderRows);
    order.customerId = customerId;
    order.orderDate = orderDate;
    order.status = OrderStatus::CONFIRMED;
    order.totalAmount = 0.0;

    int nextItemId = nextIdFromRows(itemRows);
    for (const auto &item : items) {
        OrderItem stored = item;
        stored.orderItemId = nextItemId++;
        stored.orderId = order.orderId;
        order.totalAmount += stored.lineTotal;
        itemRows.push_back(fromOrderItem(stored));
    }

    orderRows.push_back(fromOrder(order));
    writeCsv(orderFile_, "orderId,customerId,orderDate,status,totalAmount", orderRows);
    writeCsv(orderItemFile_, "orderItemId,orderId,medicineId,batchId,quantity,unitPrice,lineTotal", itemRows);
    return order;
}

bool OrderService::cancelOrder(int orderId) {
    auto orderRows = readCsv(orderFile_);
    bool updated = false;
    for (auto &row : orderRows) {
        if (!row.empty() && toInt(row[0]) == orderId) {
            if (row.size() < 5) {
                row.resize(5);
            }
            row[3] = statusToString(OrderStatus::CANCELLED);
            updated = true;
            break;
        }
    }
    if (updated) {
        writeCsv(orderFile_, "orderId,customerId,orderDate,status,totalAmount", orderRows);
    }
    return updated;
}

std::vector<Order> OrderService::listOrders() const {
    auto rows = readCsv(orderFile_);
    std::vector<Order> orders;
    for (const auto &row : rows) {
        if (row.size() >= 5) {
            orders.push_back(toOrder(row));
        }
    }
    return orders;
}

std::vector<Order> OrderService::listOrdersByCustomer(int customerId) const {
    auto orders = listOrders();
    std::vector<Order> filtered;
    for (const auto &order : orders) {
        if (order.customerId == customerId) {
            filtered.push_back(order);
        }
    }
    return filtered;
}

std::vector<OrderItem> OrderService::listOrderItems(int orderId) const {
    auto rows = readCsv(orderItemFile_);
    std::vector<OrderItem> items;
    for (const auto &row : rows) {
        if (row.size() >= 7 && toInt(row[1]) == orderId) {
            items.push_back(toOrderItem(row));
        }
    }
    return items;
}

bool OrderService::getReceipt(int orderId, OrderReceipt &receipt) const {
    auto orders = listOrders();
    auto orderIt = std::find_if(orders.begin(), orders.end(), [&](const Order &order) { return order.orderId == orderId; });
    if (orderIt == orders.end()) {
        return false;
    }

    receipt = OrderReceipt{};
    receipt.orderId = orderIt->orderId;
    receipt.orderDate = orderIt->orderDate;
    receipt.totalAmount = orderIt->totalAmount;

    auto customerRows = readCsv(customerFile_);
    for (const auto &row : customerRows) {
        if (row.size() >= 5 && toInt(row[0]) == orderIt->customerId) {
            receipt.customerName = row[1];
            receipt.customerPhone = row[2];
            break;
        }
    }

    auto medicineRows = readCsv(medicineFile_);
    auto batchRows = readCsv(batchFile_);
    auto items = listOrderItems(orderId);
    for (const auto &item : items) {
        OrderReceiptItem receiptItem;
        receiptItem.quantity = item.quantity;
        receiptItem.unitPrice = item.unitPrice;
        receiptItem.lineTotal = item.lineTotal;
        receiptItem.batchNo = "";
        receiptItem.medicineName = "";
        for (const auto &batchRow : batchRows) {
            if (batchRow.size() >= 5 && toInt(batchRow[0]) == item.batchId) {
                receiptItem.batchNo = batchRow[2];
                break;
            }
        }
        for (const auto &medRow : medicineRows) {
            if (medRow.size() >= 6 && toInt(medRow[0]) == item.medicineId) {
                receiptItem.medicineName = medRow[2];
                break;
            }
        }
        receipt.items.push_back(receiptItem);
    }
    return true;
}

Order OrderService::toOrder(const std::vector<std::string> &row) const {
    Order order;
    order.orderId = toInt(row[0]);
    order.customerId = toInt(row[1]);
    order.orderDate = row[2];
    order.status = statusFromString(row[3]);
    order.totalAmount = toDouble(row[4]);
    return order;
}

std::vector<std::string> OrderService::fromOrder(const Order &order) const {
    return {
        std::to_string(order.orderId),
        std::to_string(order.customerId),
        order.orderDate,
        statusToString(order.status),
        std::to_string(order.totalAmount)};
}

OrderItem OrderService::toOrderItem(const std::vector<std::string> &row) const {
    OrderItem item;
    item.orderItemId = toInt(row[0]);
    item.orderId = toInt(row[1]);
    item.medicineId = toInt(row[2]);
    item.batchId = toInt(row[3]);
    item.quantity = toInt(row[4]);
    item.unitPrice = toDouble(row[5]);
    item.lineTotal = toDouble(row[6]);
    return item;
}

std::vector<std::string> OrderService::fromOrderItem(const OrderItem &item) const {
    return {
        std::to_string(item.orderItemId),
        std::to_string(item.orderId),
        std::to_string(item.medicineId),
        std::to_string(item.batchId),
        std::to_string(item.quantity),
        std::to_string(item.unitPrice),
        std::to_string(item.lineTotal)};
}
