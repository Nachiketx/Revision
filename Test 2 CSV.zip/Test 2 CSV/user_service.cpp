#include "user_service.h"

#include "csv_utils.h"

#include <algorithm>

namespace {
int toInt(const std::string &value) {
    return std::stoi(value);
}

std::string roleToString(UserRole role) {
    switch (role) {
    case UserRole::ADMIN:
        return "ADMIN";
    case UserRole::PHARMACIST:
        return "PHARMACIST";
    default:
        return "CUSTOMER";
    }
}

UserRole roleFromString(const std::string &value) {
    if (value == "ADMIN") {
        return UserRole::ADMIN;
    }
    if (value == "PHARMACIST") {
        return UserRole::PHARMACIST;
    }
    return UserRole::CUSTOMER;
}
} // namespace

UserService::UserService(const std::string &userFile, const std::string &customerFile)
    : userFile_(userFile), customerFile_(customerFile) {
    ensureFileHasHeader(userFile_, "userId,username,email,name,phone,role,passwordHash,isActive");
    ensureFileHasHeader(customerFile_, "customerId,name,phone,email,address");
}

User UserService::addUser(const User &user) {
    auto rows = readCsv(userFile_);
    User stored = user;
    stored.userId = nextIdFromRows(rows);
    rows.push_back(fromUser(stored));
    writeCsv(userFile_, "userId,username,email,name,phone,role,passwordHash,isActive", rows);
    return stored;
}

bool UserService::updateUser(const User &user) {
    auto rows = readCsv(userFile_);
    bool updated = false;
    for (auto &row : rows) {
        if (!row.empty() && toInt(row[0]) == user.userId) {
            row = fromUser(user);
            updated = true;
            break;
        }
    }
    if (updated) {
        writeCsv(userFile_, "userId,username,email,name,phone,role,passwordHash,isActive", rows);
    }
    return updated;
}

bool UserService::deactivateUser(int userId) {
    auto rows = readCsv(userFile_);
    bool updated = false;
    for (auto &row : rows) {
        if (!row.empty() && toInt(row[0]) == userId) {
            if (row.size() < 8) {
                row.resize(8);
            }
            row[7] = "0";
            updated = true;
            break;
        }
    }
    if (updated) {
        writeCsv(userFile_, "userId,username,email,name,phone,role,passwordHash,isActive", rows);
    }
    return updated;
}

std::vector<User> UserService::listUsers() const {
    auto rows = readCsv(userFile_);
    std::vector<User> users;
    for (const auto &row : rows) {
        if (row.size() >= 8) {
            users.push_back(toUser(row));
        }
    }
    return users;
}

std::vector<User> UserService::listUsersByRole(UserRole role) const {
    auto users = listUsers();
    std::vector<User> filtered;
    for (const auto &user : users) {
        if (user.role == role) {
            filtered.push_back(user);
        }
    }
    return filtered;
}

Customer UserService::addCustomer(const Customer &customer) {
    auto rows = readCsv(customerFile_);
    Customer stored = customer;
    stored.customerId = nextIdFromRows(rows);
    rows.push_back(fromCustomer(stored));
    writeCsv(customerFile_, "customerId,name,phone,email,address", rows);
    return stored;
}

bool UserService::updateCustomer(const Customer &customer) {
    auto rows = readCsv(customerFile_);
    bool updated = false;
    for (auto &row : rows) {
        if (!row.empty() && toInt(row[0]) == customer.customerId) {
            row = fromCustomer(customer);
            updated = true;
            break;
        }
    }
    if (updated) {
        writeCsv(customerFile_, "customerId,name,phone,email,address", rows);
    }
    return updated;
}

std::vector<Customer> UserService::listCustomers() const {
    auto rows = readCsv(customerFile_);
    std::vector<Customer> customers;
    for (const auto &row : rows) {
        if (row.size() >= 5) {
            customers.push_back(toCustomer(row));
        }
    }
    return customers;
}

User UserService::toUser(const std::vector<std::string> &row) const {
    User user;
    user.userId = toInt(row[0]);
    user.username = row[1];
    user.email = row[2];
    user.name = row[3];
    user.phone = row[4];
    user.role = roleFromString(row[5]);
    user.passwordHash = row[6];
    user.isActive = row[7] == "1" || row[7] == "true" || row[7] == "True";
    return user;
}

std::vector<std::string> UserService::fromUser(const User &user) const {
    return {
        std::to_string(user.userId),
        user.username,
        user.email,
        user.name,
        user.phone,
        roleToString(user.role),
        user.passwordHash,
        user.isActive ? "1" : "0"};
}

Customer UserService::toCustomer(const std::vector<std::string> &row) const {
    Customer customer;
    customer.customerId = toInt(row[0]);
    customer.name = row[1];
    customer.phone = row[2];
    customer.email = row[3];
    customer.address = row[4];
    return customer;
}

std::vector<std::string> UserService::fromCustomer(const Customer &customer) const {
    return {
        std::to_string(customer.customerId),
        customer.name,
        customer.phone,
        customer.email,
        customer.address};
}
