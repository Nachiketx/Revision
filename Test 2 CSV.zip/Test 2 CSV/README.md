# Pharmacy Management System (CSV, Console, C++)

This is a simple console-based pharmacy management system with CRUD, search, notices, and receipt printing. It stores data in CSV files.

## Build

```bash
g++ -std=c++17 -O2 -o pharmacy_app \
  main.cpp csv_utils.cpp inventory_service.cpp order_service.cpp payment_service.cpp user_service.cpp report_service.cpp
```

## Run

```bash
./pharmacy_app
```

CSV files are created automatically in the working folder on first run:

- `medicines.csv`
- `batches.csv`
- `customers.csv`
- `orders.csv`
- `order_items.csv`
- `payments.csv`
- `users.csv`

## Features

- Inventory CRUD (medicines and batches)
- Search medicines by keyword
- Customer CRUD
- Place/cancel orders and print receipts
- Payment processing and refunds
- Notices: expiring stock in 14 days, low stock (<=10)
- Basic reports (counts)

## Notes

- Dates use `YYYY-MM-DD` format.
- Receipt prints automatically after placing an order and is viewable anytime.
