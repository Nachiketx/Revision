#include "csv_utils.h"

#include <fstream>
#include <sstream>

std::vector<std::string> splitCsvLine(const std::string &line) {
    std::vector<std::string> fields;
    std::string current;
    bool inQuotes = false;
    for (size_t i = 0; i < line.size(); ++i) {
        char c = line[i];
        if (c == '"') {
            if (inQuotes && i + 1 < line.size() && line[i + 1] == '"') {
                current.push_back('"');
                ++i;
            } else {
                inQuotes = !inQuotes;
            }
        } else if (c == ',' && !inQuotes) {
            fields.push_back(current);
            current.clear();
        } else {
            current.push_back(c);
        }
    }
    fields.push_back(current);
    return fields;
}

std::string joinCsvLine(const std::vector<std::string> &fields) {
    std::ostringstream out;
    for (size_t i = 0; i < fields.size(); ++i) {
        std::string field = fields[i];
        bool needQuotes = field.find(',') != std::string::npos || field.find('"') != std::string::npos;
        if (needQuotes) {
            out << '"';
            for (char c : field) {
                if (c == '"') {
                    out << "\"\"";
                } else {
                    out << c;
                }
            }
            out << '"';
        } else {
            out << field;
        }
        if (i + 1 < fields.size()) {
            out << ',';
        }
    }
    return out.str();
}

bool ensureFileHasHeader(const std::string &path, const std::string &headerLine) {
    std::ifstream in(path);
    if (in.good()) {
        return true;
    }
    std::ofstream out(path);
    if (!out.good()) {
        return false;
    }
    out << headerLine << "\n";
    return true;
}

std::vector<std::vector<std::string>> readCsv(const std::string &path, bool skipHeader) {
    std::vector<std::vector<std::string>> rows;
    std::ifstream in(path);
    if (!in.good()) {
        return rows;
    }
    std::string line;
    bool first = true;
    while (std::getline(in, line)) {
        if (first && skipHeader) {
            first = false;
            continue;
        }
        first = false;
        if (line.empty()) {
            continue;
        }
        rows.push_back(splitCsvLine(line));
    }
    return rows;
}

bool writeCsv(const std::string &path, const std::string &headerLine,
              const std::vector<std::vector<std::string>> &rows) {
    std::ofstream out(path, std::ios::trunc);
    if (!out.good()) {
        return false;
    }
    out << headerLine << "\n";
    for (const auto &row : rows) {
        out << joinCsvLine(row) << "\n";
    }
    return true;
}

int nextIdFromRows(const std::vector<std::vector<std::string>> &rows) {
    int maxId = 0;
    for (const auto &row : rows) {
        if (row.empty()) {
            continue;
        }
        try {
            int id = std::stoi(row[0]);
            if (id > maxId) {
                maxId = id;
            }
        } catch (...) {
            continue;
        }
    }
    return maxId + 1;
}
