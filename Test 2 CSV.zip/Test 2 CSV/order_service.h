#pragma once

#include "models.h"

#include <string>
#include <vector>

struct OrderReceiptItem {
    std::string medicineName;
    std::string batchNo;
    int quantity{};
    double unitPrice{};
    double lineTotal{};
};

struct OrderReceipt {
    int orderId{};
    std::string customerName;
    std::string customerPhone;
    std::string orderDate;
    std::vector<OrderReceiptItem> items;
    double totalAmount{};
};

class OrderService {
public:
    OrderService(const std::string &orderFile,
                 const std::string &orderItemFile,
                 const std::string &customerFile,
                 const std::string &medicineFile,
                 const std::string &batchFile);

    Order placeOrder(int customerId, const std::vector<OrderItem> &items, const std::string &orderDate);
    bool cancelOrder(int orderId);
    std::vector<Order> listOrders() const;
    std::vector<Order> listOrdersByCustomer(int customerId) const;
    std::vector<OrderItem> listOrderItems(int orderId) const;
    bool getReceipt(int orderId, OrderReceipt &receipt) const;

private:
    std::string orderFile_;
    std::string orderItemFile_;
    std::string customerFile_;
    std::string medicineFile_;
    std::string batchFile_;

    Order toOrder(const std::vector<std::string> &row) const;
    std::vector<std::string> fromOrder(const Order &order) const;
    OrderItem toOrderItem(const std::vector<std::string> &row) const;
    std::vector<std::string> fromOrderItem(const OrderItem &item) const;
};
